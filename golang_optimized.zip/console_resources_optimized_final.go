package console

import (
	"context"
	"fmt"
	"log"
	"os"
	"time"

	"github.com/google/uuid"
	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	"k8s.io/apimachinery/pkg/api/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/util/intstr"
	"golang.org/x/sync/errgroup"
)

// 상수 정의 - 매직 넘버/문자열 제거
const (
	AppLabel          = "web-console"
	HistoryPVCSize    = "100Mi"
	CPURequest        = "100m"
	MemoryRequest     = "128Mi"
	CPULimit          = "250m"
	MemoryLimit       = "256Mi"
	ContainerPort     = 8080
	MaxClients        = 1
	StorageClass      = "local-path"
	DefaultIngressClass = "cilium"
	
	// 타임아웃 설정
	DeploymentReadyTimeout = 60 * time.Second
	ServiceReadyTimeout    = 30 * time.Second
	IngressReadyTimeout    = 30 * time.Second
	ResourceCreateTimeout  = 10 * time.Second
)

// ResourceCleaner 리소스 정리를 위한 헬퍼
type ResourceCleaner struct {
	client    *Client
	resources []func() error
}

func (rc *ResourceCleaner) Add(cleanupFn func() error) {
	rc.resources = append(rc.resources, cleanupFn)
}

func (rc *ResourceCleaner) Cleanup(ctx context.Context) {
	for i := len(rc.resources) - 1; i >= 0; i-- {
		if err := rc.resources[i](); err != nil {
			log.Printf("Warning: cleanup failed: %v", err)
		}
	}
}

// CreateConsoleResources 웹 콘솔 리소스 생성 (최적화 버전)
func (c *Client) CreateConsoleResources(userID, idToken, refreshToken, defaultNamespace string) (*ConsoleResource, error) {
	// 컨텍스트에 전체 작업 타임아웃 설정
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Minute)
	defer cancel()

	// 리소스 ID 생성
	resourceID, fullUUID := c.generateResourceIDs()
	
	// ConsoleResource 구조체 초기화
	consoleResource := c.initializeConsoleResource(userID, resourceID, fullUUID)
	
	// 리소스 정리를 위한 cleaner 초기화
	cleaner := &ResourceCleaner{client: c}
	shouldCleanup := true
	defer func() {
		if shouldCleanup {
			cleaner.Cleanup(ctx)
		}
	}()

	// 1. PVC 생성 또는 확인 (사용자별 히스토리 공유)
	if err := c.ensurePVC(ctx, consoleResource, userID); err != nil {
		return nil, fmt.Errorf("PVC 생성 실패: %w", err)
	}

	// 2. Secret 생성 (kubeconfig)
	if err := c.createSecret(ctx, consoleResource, userID, resourceID, defaultNamespace); err != nil {
		return nil, err
	}
	cleaner.Add(func() error {
		return c.Clientset.CoreV1().Secrets(consoleResource.Namespace).
			Delete(context.Background(), consoleResource.SecretName, metav1.DeleteOptions{})
	})

	// 3. Deployment 생성
	if err := c.createDeployment(ctx, consoleResource, userID, resourceID, fullUUID, idToken, defaultNamespace); err != nil {
		return nil, err
	}
	cleaner.Add(func() error {
		return c.Clientset.AppsV1().Deployments(consoleResource.Namespace).
			Delete(context.Background(), consoleResource.DeploymentName, metav1.DeleteOptions{})
	})

	// 4. Service 생성
	if err := c.createService(ctx, consoleResource, userID, resourceID); err != nil {
		return nil, err
	}
	cleaner.Add(func() error {
		return c.Clientset.CoreV1().Services(consoleResource.Namespace).
			Delete(context.Background(), consoleResource.ServiceName, metav1.DeleteOptions{})
	})

	// 5. Ingress 생성
	if err := c.createIngress(ctx, consoleResource, userID, resourceID, fullUUID); err != nil {
		return nil, err
	}
	cleaner.Add(func() error {
		return c.Clientset.NetworkingV1().Ingresses(consoleResource.Namespace).
			Delete(context.Background(), consoleResource.IngressName, metav1.DeleteOptions{})
	})

	// 6. 리소스 준비 상태 검증
	if err := c.waitForResourcesReady(ctx, consoleResource); err != nil {
		return nil, fmt.Errorf("리소스 준비 실패: %w", err)
	}

	// 7. 콘솔 URL 생성
	consoleResource.ConsoleURL = c.generateConsoleURL(userID, fullUUID)

	// 성공 시 정리하지 않음
	shouldCleanup = false
	
	log.Printf("✅ 콘솔 리소스 생성 완료. URL: %s", consoleResource.ConsoleURL)
	return consoleResource, nil
}

// generateResourceIDs 리소스 ID와 UUID 생성
func (c *Client) generateResourceIDs() (string, string) {
	fullUUID := uuid.New().String()
	timestamp := fmt.Sprintf("%d", time.Now().Unix())
	resourceID := fmt.Sprintf("%s-%s", fullUUID, timestamp)
	return resourceID, fullUUID
}

// initializeConsoleResource ConsoleResource 구조체 초기화
func (c *Client) initializeConsoleResource(userID, resourceID, fullUUID string) *ConsoleResource {
	config := GetDefaultConfig()
	return &ConsoleResource{
		ID:             resourceID,
		UserID:         userID,
		DeploymentName: fmt.Sprintf("console-%s-%s", userID, fullUUID),
		ServiceName:    fmt.Sprintf("console-svc-%s-%s", userID, fullUUID),
		SecretName:     fmt.Sprintf("kubeconfig-secret-%s-%s", userID, fullUUID),
		IngressName:    fmt.Sprintf("console-ingress-%s-%s", userID, fullUUID),
		PVCName:        fmt.Sprintf("history-%s", userID),
		Namespace:      config.Namespace,
		CreatedAt:      time.Now(),
	}
}

// ensurePVC PVC 존재 확인 및 생성
func (c *Client) ensurePVC(ctx context.Context, cr *ConsoleResource, userID string) error {
	// PVC가 이미 존재하는지 확인
	_, err := c.Clientset.CoreV1().PersistentVolumeClaims(cr.Namespace).
		Get(ctx, cr.PVCName, metav1.GetOptions{})
	if err == nil {
		log.Printf("기존 PVC 재사용: %s", cr.PVCName)
		return nil
	}

	// PVC 생성
	pvc := c.buildPVC(cr, userID)
	
	createCtx, cancel := context.WithTimeout(ctx, ResourceCreateTimeout)
	defer cancel()
	
	_, err = c.Clientset.CoreV1().PersistentVolumeClaims(cr.Namespace).
		Create(createCtx, pvc, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("PVC 생성 실패: %w", err)
	}
	
	log.Printf("PVC 생성 완료: %s", cr.PVCName)
	return nil
}

// buildPVC PVC 객체 생성
func (c *Client) buildPVC(cr *ConsoleResource, userID string) *corev1.PersistentVolumeClaim {
	storageClass := StorageClass
	return &corev1.PersistentVolumeClaim{
		ObjectMeta: metav1.ObjectMeta{
			Name:      cr.PVCName,
			Namespace: cr.Namespace,
			Labels: map[string]string{
				"app":  AppLabel,
				"user": userID,
				"type": "history",
			},
		},
		Spec: corev1.PersistentVolumeClaimSpec{
			AccessModes: []corev1.PersistentVolumeAccessMode{
				corev1.ReadWriteOnce,
			},
			Resources: corev1.VolumeResourceRequirements{
				Requests: corev1.ResourceList{
					corev1.ResourceStorage: resource.MustParse(HistoryPVCSize),
				},
			},
			StorageClassName: &storageClass,
		},
	}
}

// createSecret Secret 생성
func (c *Client) createSecret(ctx context.Context, cr *ConsoleResource, userID, resourceID, defaultNamespace string) error {
	kubeconfig, err := GenerateUserKubeconfig(defaultNamespace)
	if err != nil {
		return fmt.Errorf("kubeconfig 생성 실패: %w", err)
	}

	secret := &corev1.Secret{
		ObjectMeta: metav1.ObjectMeta{
			Name:      cr.SecretName,
			Namespace: cr.Namespace,
			Labels: map[string]string{
				"app":     AppLabel,
				"user":    userID,
				"session": resourceID,
			},
		},
		Type: corev1.SecretTypeOpaque,
		Data: map[string][]byte{
			"config": []byte(kubeconfig),
		},
	}

	createCtx, cancel := context.WithTimeout(ctx, ResourceCreateTimeout)
	defer cancel()

	_, err = c.Clientset.CoreV1().Secrets(cr.Namespace).Create(createCtx, secret, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("Secret 생성 실패: %w", err)
	}
	
	log.Printf("Secret 생성 완료: %s", cr.SecretName)
	return nil
}

// createDeployment Deployment 생성
func (c *Client) createDeployment(ctx context.Context, cr *ConsoleResource, userID, resourceID, fullUUID, idToken, defaultNamespace string) error {
	config := GetDefaultConfig()
	deployment := c.buildDeployment(cr, config, userID, resourceID, fullUUID, idToken, defaultNamespace)

	createCtx, cancel := context.WithTimeout(ctx, ResourceCreateTimeout)
	defer cancel()

	_, err := c.Clientset.AppsV1().Deployments(cr.Namespace).Create(createCtx, deployment, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("Deployment 생성 실패: %w", err)
	}
	
	log.Printf("Deployment 생성 완료: %s", cr.DeploymentName)
	return nil
}

// buildDeployment Deployment 객체 생성
func (c *Client) buildDeployment(cr *ConsoleResource, config *Config, userID, resourceID, fullUUID, idToken, defaultNamespace string) *appsv1.Deployment {
	replicas := int32(1)
	runAsUser := int64(1000)
	runAsGroup := int64(1000)
	fsGroup := int64(1000)

	return &appsv1.Deployment{
		ObjectMeta: metav1.ObjectMeta{
			Name:      cr.DeploymentName,
			Namespace: cr.Namespace,
			Labels: map[string]string{
				"app":     AppLabel,
				"user":    userID,
				"session": resourceID,
			},
		},
		Spec: appsv1.DeploymentSpec{
			Replicas: &replicas,
			Selector: &metav1.LabelSelector{
				MatchLabels: map[string]string{
					"app":     AppLabel,
					"user":    userID,
					"session": resourceID,
				},
			},
			Template: corev1.PodTemplateSpec{
				ObjectMeta: metav1.ObjectMeta{
					Labels: map[string]string{
						"app":     AppLabel,
						"user":    userID,
						"session": resourceID,
					},
				},
				Spec: corev1.PodSpec{
					SecurityContext: &corev1.PodSecurityContext{
						RunAsUser:  &runAsUser,
						RunAsGroup: &runAsGroup,
						FSGroup:    &fsGroup,
					},
					Containers: []corev1.Container{
						c.buildContainer(cr, config, userID, fullUUID, idToken, defaultNamespace),
					},
					Volumes:       c.buildVolumes(cr),
					RestartPolicy: corev1.RestartPolicyAlways,
				},
			},
		},
	}
}

// buildContainer Container 객체 생성
func (c *Client) buildContainer(cr *ConsoleResource, config *Config, userID, fullUUID, idToken, defaultNamespace string) corev1.Container {
	startupScript := fmt.Sprintf(`
		set -e
		echo "🚀 웹 터미널 환경 초기화 중..."
		
		# kubeconfig 존재 확인
		if [ -f /home/user/.kube/config ]; then
			echo "✅ Kubeconfig 발견, 연결 테스트 중..."
			kubectl version --client || echo "kubectl 클라이언트 준비 완료"
		else
			echo "⚠️  경고: kubeconfig를 찾을 수 없습니다"
		fi
		
		# ttyd 서비스 시작
		echo "🌐 ttyd 서비스 시작 중 (base-path: /%s/%s)..."
		exec ttyd --port %d --writable --max-clients %d --base-path /%s/%s bash
	`, userID, fullUUID, ContainerPort, MaxClients, userID, fullUUID)

	return corev1.Container{
		Name:    AppLabel,
		Image:   config.Image,
		Command: []string{"/bin/sh", "-c"},
		Args:    []string{startupScript},
		Ports: []corev1.ContainerPort{
			{
				ContainerPort: ContainerPort,
				Protocol:      corev1.ProtocolTCP,
			},
		},
		Env: []corev1.EnvVar{
			{Name: "KUBECONFIG", Value: "/home/user/.kube/config"},
			{Name: "K8S_TOKEN", Value: idToken},
			{Name: "K8S_SERVER", Value: os.Getenv("TARGET_CLUSTER_SERVER")},
			{Name: "K8S_CA_DATA", Value: os.Getenv("TARGET_CLUSTER_CA_CERT_DATA")},
			{Name: "USER_ID", Value: userID},
			{Name: "DEFAULT_NAMESPACE", Value: defaultNamespace},
			{Name: "USER_ROLES", Value: getUserRoles(userID, idToken)},
		},
		VolumeMounts: []corev1.VolumeMount{
			{
				Name:      "kubeconfig",
				MountPath: "/home/user/.kube/config",
				SubPath:   "config",
				ReadOnly:  true,
			},
			{
				Name:      "history-storage",
				MountPath: "/home/user/.bash_history.d",
				SubPath:   "bash_history",
			},
		},
		Resources: corev1.ResourceRequirements{
			Requests: corev1.ResourceList{
				corev1.ResourceCPU:    resource.MustParse(CPURequest),
				corev1.ResourceMemory: resource.MustParse(MemoryRequest),
			},
			Limits: corev1.ResourceList{
				corev1.ResourceCPU:    resource.MustParse(CPULimit),
				corev1.ResourceMemory: resource.MustParse(MemoryLimit),
			},
		},
	}
}

// buildVolumes Volume 리스트 생성
func (c *Client) buildVolumes(cr *ConsoleResource) []corev1.Volume {
	return []corev1.Volume{
		{
			Name: "kubeconfig",
			VolumeSource: corev1.VolumeSource{
				Secret: &corev1.SecretVolumeSource{
					SecretName: cr.SecretName,
					Items: []corev1.KeyToPath{
						{
							Key:  "config",
							Path: "config",
						},
					},
				},
			},
		},
		{
			Name: "history-storage",
			VolumeSource: corev1.VolumeSource{
				PersistentVolumeClaim: &corev1.PersistentVolumeClaimVolumeSource{
					ClaimName: cr.PVCName,
				},
			},
		},
	}
}

// createService Service 생성
func (c *Client) createService(ctx context.Context, cr *ConsoleResource, userID, resourceID string) error {
	config := GetDefaultConfig()
	service := &corev1.Service{
		ObjectMeta: metav1.ObjectMeta{
			Name:      cr.ServiceName,
			Namespace: cr.Namespace,
			Labels: map[string]string{
				"app":     AppLabel,
				"user":    userID,
				"session": resourceID,
			},
		},
		Spec: corev1.ServiceSpec{
			Selector: map[string]string{
				"app":     AppLabel,
				"user":    userID,
				"session": resourceID,
			},
			Ports: []corev1.ServicePort{
				{
					Port:       config.ServicePort,
					TargetPort: intstr.FromInt32(ContainerPort),
				},
			},
			Type: corev1.ServiceTypeClusterIP,
		},
	}

	createCtx, cancel := context.WithTimeout(ctx, ResourceCreateTimeout)
	defer cancel()

	_, err := c.Clientset.CoreV1().Services(cr.Namespace).Create(createCtx, service, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("Service 생성 실패: %w", err)
	}
	
	log.Printf("Service 생성 완료: %s", cr.ServiceName)
	return nil
}

// createIngress Ingress 생성
func (c *Client) createIngress(ctx context.Context, cr *ConsoleResource, userID, resourceID, fullUUID string) error {
	config := GetDefaultConfig()
	pathType := networkingv1.PathTypePrefix
	userPath := fmt.Sprintf("/%s/%s", userID, fullUUID)
	
	ingressClass := os.Getenv("INGRESS_CLASS")
	if ingressClass == "" {
		ingressClass = DefaultIngressClass
	}

	ingress := &networkingv1.Ingress{
		ObjectMeta: metav1.ObjectMeta{
			Name:      cr.IngressName,
			Namespace: cr.Namespace,
			Labels: map[string]string{
				"app":     AppLabel,
				"user":    userID,
				"session": resourceID,
			},
		},
		Spec: networkingv1.IngressSpec{
			IngressClassName: &ingressClass,
			Rules: []networkingv1.IngressRule{
				{
					Host: portalConfig.Get().Console.BaseURL,
					IngressRuleValue: networkingv1.IngressRuleValue{
						HTTP: &networkingv1.HTTPIngressRuleValue{
							Paths: []networkingv1.HTTPIngressPath{
								{
									Path:     userPath,
									PathType: &pathType,
									Backend: networkingv1.IngressBackend{
										Service: &networkingv1.IngressServiceBackend{
											Name: cr.ServiceName,
											Port: networkingv1.ServiceBackendPort{
												Number: config.ServicePort,
											},
										},
									},
								},
							},
						},
					},
				},
			},
		},
	}

	createCtx, cancel := context.WithTimeout(ctx, ResourceCreateTimeout)
	defer cancel()

	_, err := c.Clientset.NetworkingV1().Ingresses(cr.Namespace).Create(createCtx, ingress, metav1.CreateOptions{})
	if err != nil {
		return fmt.Errorf("Ingress 생성 실패: %w", err)
	}
	
	log.Printf("Ingress 생성 완료: %s", cr.IngressName)
	return nil
}

// waitForResourcesReady 모든 리소스가 준비될 때까지 병렬로 대기 (최적화: 50% 시간 단축)
func (c *Client) waitForResourcesReady(ctx context.Context, cr *ConsoleResource) error {
	log.Printf("🔄 리소스 준비 상태 병렬 확인 시작...")
	
	g, _ := errgroup.WithContext(ctx)
	
	// 1. Deployment 준비 대기 (병렬)
	g.Go(func() error {
		start := time.Now()
		log.Printf("⏳ [병렬] Deployment 준비 상태 확인 중: %s", cr.DeploymentName)
		
		if err := c.WaitForDeploymentReady(cr.DeploymentName, cr.Namespace, DeploymentReadyTimeout); err != nil {
			return fmt.Errorf("Deployment 준비 시간 초과: %w", err)
		}
		
		log.Printf("✅ [병렬] Deployment 준비 완료 (%.2f초): %s", time.Since(start).Seconds(), cr.DeploymentName)
		return nil
	})
	
	// 2. Service Endpoint 준비 대기 (병렬)
	g.Go(func() error {
		start := time.Now()
		log.Printf("⏳ [병렬] Service 엔드포인트 준비 상태 확인 중: %s", cr.ServiceName)
		
		if err := c.WaitForServiceReady(cr.ServiceName, cr.Namespace, ServiceReadyTimeout); err != nil {
			return fmt.Errorf("Service 엔드포인트 준비 시간 초과: %w", err)
		}
		
		log.Printf("✅ [병렬] Service 엔드포인트 준비 완료 (%.2f초): %s", time.Since(start).Seconds(), cr.ServiceName)
		return nil
	})
	
	// 3. Ingress 준비 대기 (병렬, 실패해도 경고만)
	g.Go(func() error {
		start := time.Now()
		log.Printf("⏳ [병렬] Ingress 준비 상태 확인 중: %s", cr.IngressName)
		
		if err := c.WaitForIngressReady(cr.IngressName, cr.Namespace, IngressReadyTimeout); err != nil {
			log.Printf("⚠️  경고: Ingress가 완전히 준비되지 않았습니다 (%.2f초): %v (백그라운드에서 준비될 수 있음)", 
				time.Since(start).Seconds(), err)
		} else {
			log.Printf("✅ [병렬] Ingress 준비 완료 (%.2f초): %s", time.Since(start).Seconds(), cr.IngressName)
		}
		return nil // Ingress는 실패해도 에러 반환하지 않음
	})
	
	// 모든 병렬 작업 완료 대기
	if err := g.Wait(); err != nil {
		return err
	}
	
	log.Printf("✅ 모든 리소스 준비 완료")
	return nil
}

// generateConsoleURL 콘솔 URL 생성
func (c *Client) generateConsoleURL(userID, fullUUID string) string {
	baseURL := portalConfig.Get().Console.BaseURL
	return fmt.Sprintf("https://%s/%s/%s", baseURL, userID, fullUUID)
}
