# 병렬 리소스 대기 최적화 가이드

## 📊 성능 비교

### ❌ 기존 순차 방식
```
시작
 ↓
Deployment 대기 -------- 60초 ------->
                                      ↓
                        Service 대기 --- 30초 --->
                                                  ↓
                                    Ingress 대기 --- 30초 -->
                                                              ↓
                                                            완료
총 소요 시간: 최대 120초
```

### ✅ 병렬 처리 방식
```
시작
 ↓
 ├─ Deployment 대기 -------- 60초 -------> ✅
 ├─ Service 대기 --- 30초 --> ✅
 └─ Ingress 대기 --- 30초 --> ✅
                                           ↓
                                         완료
총 소요 시간: 최대 60초 (가장 오래 걸리는 것만큼)
```

### 🚀 성능 개선
| 시나리오 | 순차 방식 | 병렬 방식 | 개선율 |
|---------|----------|----------|--------|
| 모두 성공 | 120초 | 60초 | **50% 단축** |
| Deployment 실패 | 60초 | 60초 | 동일 |
| Service 실패 | 90초 | 60초 | **33% 단축** |
| 평균 | 90초 | 57초 | **37% 단축** |

---

## 🎯 세 가지 병렬 처리 방법

### 1️⃣ errgroup 방식 (권장)
```go
func (c *Client) waitForResourcesReady(ctx context.Context, cr *ConsoleResource) error {
    g, gCtx := errgroup.WithContext(ctx)
    
    g.Go(func() error {
        return c.WaitForDeploymentReady(...)
    })
    
    g.Go(func() error {
        return c.WaitForServiceReady(...)
    })
    
    g.Go(func() error {
        // Ingress는 실패해도 에러 반환 안 함
        if err := c.WaitForIngressReady(...); err != nil {
            log.Printf("경고: %v", err)
        }
        return nil
    })
    
    return g.Wait()
}
```

**장점:**
- ✅ 간결하고 읽기 쉬움
- ✅ 하나라도 에러 나면 자동으로 컨텍스트 취소
- ✅ 에러 핸들링이 명확
- ✅ `golang.org/x/sync/errgroup` 표준 패키지

**단점:**
- ⚠️ 외부 패키지 의존성 (하지만 공식 패키지)
- ⚠️ 세밀한 에러 제어가 어려움 (하나 실패하면 전체 취소)

**사용 시기:**
- 👍 대부분의 경우 (가장 권장)
- 👍 코드 간결성이 중요한 경우
- 👍 빠른 실패(fail-fast)가 필요한 경우

---

### 2️⃣ sync.WaitGroup 방식
```go
func (c *Client) waitForResourcesReadyWithSync(ctx context.Context, cr *ConsoleResource) error {
    var wg sync.WaitGroup
    var mu sync.Mutex
    var errors []error
    
    wg.Add(1)
    go func() {
        defer wg.Done()
        if err := c.WaitForDeploymentReady(...); err != nil {
            mu.Lock()
            errors = append(errors, err)
            mu.Unlock()
        }
    }()
    
    wg.Add(1)
    go func() {
        defer wg.Done()
        if err := c.WaitForServiceReady(...); err != nil {
            mu.Lock()
            errors = append(errors, err)
            mu.Unlock()
        }
    }()
    
    wg.Wait()
    
    if len(errors) > 0 {
        return fmt.Errorf("리소스 준비 실패: %v", errors)
    }
    return nil
}
```

**장점:**
- ✅ 표준 라이브러리만 사용
- ✅ 모든 에러를 수집 가능
- ✅ 하나 실패해도 나머지 계속 진행
- ✅ 더 세밀한 제어 가능

**단점:**
- ⚠️ 코드가 더 장황함
- ⚠️ 뮤텍스 관리 필요
- ⚠️ 컨텍스트 취소 처리를 직접 구현해야 함

**사용 시기:**
- 👍 외부 패키지를 피해야 하는 경우
- 👍 모든 에러를 수집해야 하는 경우
- 👍 하나 실패해도 나머지를 계속 진행해야 하는 경우

---

### 3️⃣ 고급 방식 (설정 기반)
```go
type resourceCheck struct {
    name      string
    checkFunc func() error
    timeout   time.Duration
    critical  bool  // false면 실패해도 계속
}

checks := []resourceCheck{
    {
        name:     "Deployment",
        checkFunc: func() error { return c.WaitForDeploymentReady(...) },
        timeout:  60 * time.Second,
        critical: true,
    },
    {
        name:     "Ingress",
        checkFunc: func() error { return c.WaitForIngressReady(...) },
        timeout:  30 * time.Second,
        critical: false,  // 실패해도 OK
    },
}

// 루프로 처리
for _, check := range checks {
    go func(c resourceCheck) {
        // 개별 타임아웃 및 critical 체크
    }(check)
}
```

**장점:**
- ✅ 확장성이 매우 높음
- ✅ 리소스 추가/제거가 쉬움
- ✅ 개별 타임아웃 설정 가능
- ✅ critical/non-critical 구분
- ✅ 진행률 표시 가능

**단점:**
- ⚠️ 코드가 가장 복잡함
- ⚠️ 오버 엔지니어링 가능성
- ⚠️ 디버깅이 어려울 수 있음

**사용 시기:**
- 👍 리소스가 많은 경우 (5개 이상)
- 👍 동적으로 리소스 체크 목록이 바뀌는 경우
- 👍 진행률 표시가 필요한 경우
- 👍 개별 타임아웃이 다른 경우

---

## 📋 방법별 비교표

| 항목 | errgroup | WaitGroup | 고급 방식 |
|------|----------|-----------|-----------|
| 코드 간결성 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ |
| 에러 처리 | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| 확장성 | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| 표준 라이브러리 | ❌ (공식 확장) | ✅ | ✅ |
| 학습 곡선 | 낮음 | 중간 | 높음 |
| 성능 | 동일 | 동일 | 동일 |
| 권장도 | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |

---

## 💡 권장 사항

### 현재 프로젝트에는 errgroup 방식 추천!

**이유:**
1. ✅ **코드 간결성** - 가장 읽기 쉽고 이해하기 쉬움
2. ✅ **충분한 기능** - 대부분의 요구사항 충족
3. ✅ **신뢰성** - Google이 유지관리하는 공식 패키지
4. ✅ **빠른 실패** - 하나 실패하면 전체 취소 (원하는 동작)

### 구현 예시

**기존 코드 (순차):**
```go
func (c *Client) waitForResourcesReady(ctx context.Context, cr *ConsoleResource) error {
    // Deployment 대기 - 60초
    if err := c.WaitForDeploymentReady(...); err != nil {
        return err
    }
    
    // Service 대기 - 30초
    if err := c.WaitForServiceReady(...); err != nil {
        return err
    }
    
    // Ingress 대기 - 30초 (경고만)
    if err := c.WaitForIngressReady(...); err != nil {
        log.Printf("경고: %v", err)
    }
    
    return nil
}
```

**최적화 코드 (병렬):**
```go
import "golang.org/x/sync/errgroup"

func (c *Client) waitForResourcesReady(ctx context.Context, cr *ConsoleResource) error {
    log.Printf("🔄 리소스 준비 상태 병렬 확인 시작...")
    
    g, _ := errgroup.WithContext(ctx)
    
    // Deployment 체크 (병렬)
    g.Go(func() error {
        start := time.Now()
        log.Printf("⏳ [병렬] Deployment 준비 확인 중...")
        
        if err := c.WaitForDeploymentReady(cr.DeploymentName, cr.Namespace, DeploymentReadyTimeout); err != nil {
            return fmt.Errorf("Deployment 준비 실패: %w", err)
        }
        
        log.Printf("✅ [병렬] Deployment 준비 완료 (%.2fs)", time.Since(start).Seconds())
        return nil
    })
    
    // Service 체크 (병렬)
    g.Go(func() error {
        start := time.Now()
        log.Printf("⏳ [병렬] Service 준비 확인 중...")
        
        if err := c.WaitForServiceReady(cr.ServiceName, cr.Namespace, ServiceReadyTimeout); err != nil {
            return fmt.Errorf("Service 준비 실패: %w", err)
        }
        
        log.Printf("✅ [병렬] Service 준비 완료 (%.2fs)", time.Since(start).Seconds())
        return nil
    })
    
    // Ingress 체크 (병렬, 실패해도 OK)
    g.Go(func() error {
        start := time.Now()
        log.Printf("⏳ [병렬] Ingress 준비 확인 중...")
        
        if err := c.WaitForIngressReady(cr.IngressName, cr.Namespace, IngressReadyTimeout); err != nil {
            log.Printf("⚠️  경고: Ingress 미준비 (%.2fs): %v", time.Since(start).Seconds(), err)
        } else {
            log.Printf("✅ [병렬] Ingress 준비 완료 (%.2fs)", time.Since(start).Seconds())
        }
        return nil  // 실패해도 nil 반환
    })
    
    // 모든 작업 완료 대기
    if err := g.Wait(); err != nil {
        return err
    }
    
    log.Printf("✅ 모든 리소스 준비 완료")
    return nil
}
```

---

## 🔧 마이그레이션 단계

### Step 1: 의존성 추가
```bash
go get golang.org/x/sync/errgroup
```

### Step 2: 함수 교체
```go
// 기존 console_resources_optimized.go에서
// waitForResourcesReady 함수만 교체

// import 추가
import "golang.org/x/sync/errgroup"

// 함수 교체
func (c *Client) waitForResourcesReady(ctx context.Context, cr *ConsoleResource) error {
    // 위의 병렬 코드 사용
}
```

### Step 3: 테스트
```go
// 테스트 시나리오
func TestParallelWait(t *testing.T) {
    start := time.Now()
    err := client.waitForResourcesReady(ctx, cr)
    duration := time.Since(start)
    
    // 병렬 처리 확인: 90초보다 훨씬 짧아야 함
    if duration > 70*time.Second {
        t.Errorf("병렬 처리 미작동: %v", duration)
    }
}
```

---

## 📈 실제 성능 측정 예시

### 순차 방식 (기존)
```
2025-11-10 10:00:00 ⏳ Deployment 준비 상태 확인 중...
2025-11-10 10:01:00 ✅ Deployment 준비 완료             [60초 소요]
2025-11-10 10:01:00 ⏳ Service 엔드포인트 준비 상태 확인 중...
2025-11-10 10:01:30 ✅ Service 엔드포인트 준비 완료       [30초 소요]
2025-11-10 10:01:30 ⏳ Ingress 준비 상태 확인 중...
2025-11-10 10:02:00 ✅ Ingress 준비 완료                [30초 소요]

총 소요 시간: 120초
```

### 병렬 방식 (최적화)
```
2025-11-10 10:00:00 🔄 리소스 준비 상태 병렬 확인 시작...
2025-11-10 10:00:00 ⏳ [병렬] Deployment 준비 확인 중...
2025-11-10 10:00:00 ⏳ [병렬] Service 준비 확인 중...
2025-11-10 10:00:00 ⏳ [병렬] Ingress 준비 확인 중...
2025-11-10 10:00:30 ✅ [병렬] Service 준비 완료 (30.2s)   [동시 진행]
2025-11-10 10:00:30 ✅ [병렬] Ingress 준비 완료 (30.4s)   [동시 진행]
2025-11-10 10:01:00 ✅ [병렬] Deployment 준비 완료 (60.1s) [동시 진행]
2025-11-10 10:01:00 ✅ 모든 리소스 준비 완료

총 소요 시간: 60초 (50% 단축!)
```

---

## ⚠️ 주의사항

### 1. goroutine leak 방지
```go
// ❌ 나쁜 예
go func() {
    c.WaitForDeploymentReady(...)  // 에러를 처리하지 않으면 leak
}()

// ✅ 좋은 예
g.Go(func() error {
    return c.WaitForDeploymentReady(...)  // errgroup이 관리
})
```

### 2. race condition 방지
```go
// ❌ 나쁜 예
var err error
go func() {
    err = c.WaitForDeploymentReady(...)  // race condition!
}()

// ✅ 좋은 예
g.Go(func() error {
    return c.WaitForDeploymentReady(...)  // errgroup이 안전하게 관리
})
```

### 3. 컨텍스트 취소 전파
```go
// errgroup은 자동으로 컨텍스트 취소를 전파
g, gCtx := errgroup.WithContext(ctx)

// gCtx는 하나라도 에러 나면 자동 취소됨
g.Go(func() error {
    return c.WaitWithContext(gCtx, ...)  // gCtx 사용
})
```

---

## 🎯 최종 권장사항

### 현재 프로젝트 적용 순서

1. **즉시 적용: errgroup 방식** ✅
   - 가장 간단하고 효과적
   - 50% 성능 향상
   - 10줄 정도만 수정

2. **향후 고려: 고급 방식** 🔮
   - 리소스가 더 늘어나면 (5개 이상)
   - 진행률 표시가 필요하면
   - 개별 설정이 필요하면

### 의존성
```go
// go.mod에 추가
require golang.org/x/sync v0.5.0
```

### 예상 효과
- ⚡ **성능**: 리소스 대기 시간 50% 단축 (120초 → 60초)
- 🎯 **안정성**: 동일 (에러 처리 동일)
- 📝 **코드 품질**: 향상 (모던한 패턴 사용)
- 🔧 **유지보수**: 향상 (더 명확한 의도 표현)

---

**결론:** errgroup을 사용한 병렬 처리로 간단하게 50% 성능 향상! 🚀
