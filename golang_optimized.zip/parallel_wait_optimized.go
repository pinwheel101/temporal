package console

import (
	"context"
	"fmt"
	"log"
	"sync"
	"time"

	"golang.org/x/sync/errgroup"
)

// waitForResourcesReady 모든 리소스가 준비될 때까지 병렬로 대기 (최적화 버전)
func (c *Client) waitForResourcesReady(ctx context.Context, cr *ConsoleResource) error {
	log.Printf("🔄 리소스 준비 상태 병렬 확인 시작...")
	
	// errgroup 사용: 하나라도 에러 나면 전체 취소
	g, gCtx := errgroup.WithContext(ctx)
	
	// 결과를 저장할 채널 (로깅용)
	type checkResult struct {
		resource string
		success  bool
		duration time.Duration
		err      error
	}
	resultChan := make(chan checkResult, 3)
	
	// 1. Deployment 준비 대기 (고루틴)
	g.Go(func() error {
		start := time.Now()
		log.Printf("⏳ [병렬] Deployment 준비 상태 확인 중: %s", cr.DeploymentName)
		
		err := c.WaitForDeploymentReady(cr.DeploymentName, cr.Namespace, DeploymentReadyTimeout)
		duration := time.Since(start)
		
		resultChan <- checkResult{
			resource: "Deployment",
			success:  err == nil,
			duration: duration,
			err:      err,
		}
		
		if err != nil {
			return fmt.Errorf("Deployment 준비 시간 초과: %w", err)
		}
		return nil
	})
	
	// 2. Service Endpoint 준비 대기 (고루틴)
	g.Go(func() error {
		start := time.Now()
		log.Printf("⏳ [병렬] Service 엔드포인트 준비 상태 확인 중: %s", cr.ServiceName)
		
		err := c.WaitForServiceReady(cr.ServiceName, cr.Namespace, ServiceReadyTimeout)
		duration := time.Since(start)
		
		resultChan <- checkResult{
			resource: "Service",
			success:  err == nil,
			duration: duration,
			err:      err,
		}
		
		if err != nil {
			return fmt.Errorf("Service 엔드포인트 준비 시간 초과: %w", err)
		}
		return nil
	})
	
	// 3. Ingress 준비 대기 (고루틴) - 실패해도 경고만
	g.Go(func() error {
		start := time.Now()
		log.Printf("⏳ [병렬] Ingress 준비 상태 확인 중: %s", cr.IngressName)
		
		err := c.WaitForIngressReady(cr.IngressName, cr.Namespace, IngressReadyTimeout)
		duration := time.Since(start)
		
		resultChan <- checkResult{
			resource: "Ingress",
			success:  err == nil,
			duration: duration,
			err:      err,
		}
		
		// Ingress는 실패해도 에러 반환하지 않음 (경고만)
		if err != nil {
			log.Printf("⚠️  경고: Ingress가 완전히 준비되지 않았습니다: %v (백그라운드에서 준비될 수 있음)", err)
		}
		return nil
	})
	
	// 결과 수집 고루틴
	go func() {
		for i := 0; i < 3; i++ {
			result := <-resultChan
			if result.success {
				log.Printf("✅ [병렬] %s 준비 완료 (소요 시간: %.2f초)", 
					result.resource, result.duration.Seconds())
			}
		}
		close(resultChan)
	}()
	
	// 모든 고루틴이 완료될 때까지 대기
	if err := g.Wait(); err != nil {
		return err
	}
	
	log.Printf("✅ 모든 리소스 준비 완료")
	return nil
}

// waitForResourcesReadyWithSync sync.WaitGroup을 사용한 대안 (에러 처리가 더 유연함)
func (c *Client) waitForResourcesReadyWithSync(ctx context.Context, cr *ConsoleResource) error {
	log.Printf("🔄 리소스 준비 상태 병렬 확인 시작...")
	
	var wg sync.WaitGroup
	var mu sync.Mutex
	var errors []error
	
	// 1. Deployment 준비 대기
	wg.Add(1)
	go func() {
		defer wg.Done()
		start := time.Now()
		log.Printf("⏳ [병렬] Deployment 준비 상태 확인 중: %s", cr.DeploymentName)
		
		if err := c.WaitForDeploymentReady(cr.DeploymentName, cr.Namespace, DeploymentReadyTimeout); err != nil {
			mu.Lock()
			errors = append(errors, fmt.Errorf("Deployment 준비 실패: %w", err))
			mu.Unlock()
		} else {
			log.Printf("✅ [병렬] Deployment 준비 완료 (소요 시간: %.2f초)", 
				time.Since(start).Seconds())
		}
	}()
	
	// 2. Service Endpoint 준비 대기
	wg.Add(1)
	go func() {
		defer wg.Done()
		start := time.Now()
		log.Printf("⏳ [병렬] Service 엔드포인트 준비 상태 확인 중: %s", cr.ServiceName)
		
		if err := c.WaitForServiceReady(cr.ServiceName, cr.Namespace, ServiceReadyTimeout); err != nil {
			mu.Lock()
			errors = append(errors, fmt.Errorf("Service 준비 실패: %w", err))
			mu.Unlock()
		} else {
			log.Printf("✅ [병렬] Service 준비 완료 (소요 시간: %.2f초)", 
				time.Since(start).Seconds())
		}
	}()
	
	// 3. Ingress 준비 대기 (실패해도 경고만)
	wg.Add(1)
	go func() {
		defer wg.Done()
		start := time.Now()
		log.Printf("⏳ [병렬] Ingress 준비 상태 확인 중: %s", cr.IngressName)
		
		if err := c.WaitForIngressReady(cr.IngressName, cr.Namespace, IngressReadyTimeout); err != nil {
			log.Printf("⚠️  경고: Ingress가 완전히 준비되지 않았습니다: %v (백그라운드에서 준비될 수 있음)", err)
		} else {
			log.Printf("✅ [병렬] Ingress 준비 완료 (소요 시간: %.2f초)", 
				time.Since(start).Seconds())
		}
	}()
	
	// 모든 고루틴 완료 대기
	wg.Wait()
	
	// 에러가 있으면 반환 (Ingress 제외)
	if len(errors) > 0 {
		return fmt.Errorf("리소스 준비 실패: %v", errors)
	}
	
	log.Printf("✅ 모든 리소스 준비 완료")
	return nil
}

// waitForResourcesReadyAdvanced 더욱 고급 버전: 컨텍스트 취소, 개별 타임아웃, 진행률 표시
func (c *Client) waitForResourcesReadyAdvanced(ctx context.Context, cr *ConsoleResource) error {
	log.Printf("🔄 리소스 준비 상태 병렬 확인 시작...")
	
	type resourceCheck struct {
		name        string
		checkFunc   func() error
		timeout     time.Duration
		critical    bool // false면 실패해도 계속 진행
	}
	
	checks := []resourceCheck{
		{
			name: "Deployment",
			checkFunc: func() error {
				return c.WaitForDeploymentReady(cr.DeploymentName, cr.Namespace, DeploymentReadyTimeout)
			},
			timeout:  DeploymentReadyTimeout,
			critical: true,
		},
		{
			name: "Service",
			checkFunc: func() error {
				return c.WaitForServiceReady(cr.ServiceName, cr.Namespace, ServiceReadyTimeout)
			},
			timeout:  ServiceReadyTimeout,
			critical: true,
		},
		{
			name: "Ingress",
			checkFunc: func() error {
				return c.WaitForIngressReady(cr.IngressName, cr.Namespace, IngressReadyTimeout)
			},
			timeout:  IngressReadyTimeout,
			critical: false, // Ingress는 실패해도 OK
		},
	}
	
	var wg sync.WaitGroup
	var mu sync.Mutex
	criticalErrors := make([]error, 0)
	completed := 0
	total := len(checks)
	
	for _, check := range checks {
		wg.Add(1)
		
		// 클로저 변수 캡처 문제 해결
		check := check
		
		go func() {
			defer wg.Done()
			
			start := time.Now()
			log.Printf("⏳ [병렬 %d/%d] %s 준비 상태 확인 중...", completed+1, total, check.name)
			
			// 개별 타임아웃 컨텍스트
			checkCtx, cancel := context.WithTimeout(ctx, check.timeout)
			defer cancel()
			
			// 체크 함수 실행 (goroutine에서)
			errChan := make(chan error, 1)
			go func() {
				errChan <- check.checkFunc()
			}()
			
			// 결과 또는 타임아웃 대기
			select {
			case err := <-errChan:
				duration := time.Since(start)
				
				mu.Lock()
				completed++
				currentCompleted := completed
				mu.Unlock()
				
				if err != nil {
					if check.critical {
						mu.Lock()
						criticalErrors = append(criticalErrors, 
							fmt.Errorf("%s 준비 실패 (%.2f초): %w", check.name, duration.Seconds(), err))
						mu.Unlock()
						log.Printf("❌ [병렬 %d/%d] %s 준비 실패 (%.2f초)", 
							currentCompleted, total, check.name, duration.Seconds())
					} else {
						log.Printf("⚠️  [병렬 %d/%d] %s 준비 미완료 (%.2f초): %v", 
							currentCompleted, total, check.name, duration.Seconds(), err)
					}
				} else {
					log.Printf("✅ [병렬 %d/%d] %s 준비 완료 (%.2f초)", 
						currentCompleted, total, check.name, duration.Seconds())
				}
				
			case <-checkCtx.Done():
				mu.Lock()
				completed++
				currentCompleted := completed
				mu.Unlock()
				
				if check.critical {
					mu.Lock()
					criticalErrors = append(criticalErrors, 
						fmt.Errorf("%s 준비 타임아웃 (%s)", check.name, check.timeout))
					mu.Unlock()
					log.Printf("❌ [병렬 %d/%d] %s 준비 타임아웃 (%s)", 
						currentCompleted, total, check.name, check.timeout)
				} else {
					log.Printf("⚠️  [병렬 %d/%d] %s 준비 타임아웃 (%s)", 
						currentCompleted, total, check.name, check.timeout)
				}
			}
		}()
	}
	
	// 모든 체크 완료 대기
	wg.Wait()
	
	// Critical 에러가 있으면 반환
	if len(criticalErrors) > 0 {
		return fmt.Errorf("리소스 준비 실패: %v", criticalErrors)
	}
	
	log.Printf("✅ 모든 리소스 준비 완료")
	return nil
}
