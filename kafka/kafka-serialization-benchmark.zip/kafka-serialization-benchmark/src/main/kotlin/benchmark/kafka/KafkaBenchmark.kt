package benchmark.kafka

import benchmark.generator.TestDataGenerator
import benchmark.model.BenchmarkMessage
import benchmark.serializer.*
import org.apache.kafka.clients.admin.AdminClient
import org.apache.kafka.clients.admin.NewTopic
import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.kafka.clients.consumer.KafkaConsumer
import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.common.serialization.ByteArrayDeserializer
import org.apache.kafka.common.serialization.ByteArraySerializer
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.kafka.common.serialization.StringSerializer
import java.time.Duration
import java.util.*
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/**
 * Kafka 통합 벤치마크 결과
 */
data class KafkaBenchmarkResult(
    val serializerName: String,
    val messageCount: Int,
    val payloadSize: Int,
    val producerTimeMs: Long,
    val consumerTimeMs: Long,
    val totalBytesProduced: Long,
    val producerThroughput: Double, // msg/sec
    val consumerThroughput: Double, // msg/sec
    val producerBandwidth: Double, // MB/sec
    val consumerBandwidth: Double  // MB/sec
)

/**
 * Kafka Producer/Consumer 통합 벤치마크
 */
class KafkaBenchmark(
    private val bootstrapServers: String,
    private val topicPrefix: String = "benchmark"
) {
    
    /**
     * 전체 벤치마크 실행
     */
    fun runFullBenchmark(
        messageCount: Int = 100000,
        payloadSizes: List<Int> = listOf(100, 1000, 10000)
    ): List<KafkaBenchmarkResult> {
        val serializers = listOf(
            JsonSerializer(),
            MessagePackSerializer(),
            AvroSerializer(),
            ProtobufSerializer()
        )
        
        val results = mutableListOf<KafkaBenchmarkResult>()
        
        println("=" .repeat(80))
        println("Kafka 통합 벤치마크 (Producer/Consumer)")
        println("=" .repeat(80))
        println("Bootstrap Servers: $bootstrapServers")
        println("메시지 수: $messageCount")
        println()
        
        for (payloadSize in payloadSizes) {
            println("-".repeat(80))
            println("페이로드 크기: $payloadSize bytes")
            println("-".repeat(80))
            
            // 테스트 데이터 생성
            val messages = TestDataGenerator.generateMessages(messageCount, payloadSize)
            
            for (serializer in serializers) {
                try {
                    val topicName = "${topicPrefix}-${serializer.name.lowercase()}-$payloadSize"
                    println("\n[${serializer.name}] 토픽: $topicName")
                    
                    // 토픽 생성
                    createTopicIfNotExists(topicName)
                    
                    // 벤치마크 실행
                    val result = runKafkaBenchmark(serializer, messages, topicName, payloadSize)
                    results.add(result)
                    printKafkaResult(result)
                    
                } catch (e: Exception) {
                    println("${serializer.name}: 오류 - ${e.message}")
                    e.printStackTrace()
                }
            }
        }
        
        return results
    }
    
    private fun createTopicIfNotExists(topicName: String) {
        val props = Properties().apply {
            put("bootstrap.servers", bootstrapServers)
        }
        
        AdminClient.create(props).use { admin ->
            val existingTopics = admin.listTopics().names().get()
            if (!existingTopics.contains(topicName)) {
                val newTopic = NewTopic(topicName, 3, 1.toShort())
                admin.createTopics(listOf(newTopic)).all().get()
                println("  토픽 생성됨: $topicName")
                Thread.sleep(1000) // 토픽 생성 대기
            }
        }
    }
    
    private fun runKafkaBenchmark(
        serializer: MessageSerializer,
        messages: List<BenchmarkMessage>,
        topicName: String,
        payloadSize: Int
    ): KafkaBenchmarkResult {
        val serializedMessages = messages.map { serializer.serialize(it) }
        val totalBytes = serializedMessages.sumOf { it.size.toLong() }
        
        // Producer 벤치마크
        val producerTime = runProducerBenchmark(topicName, serializedMessages)
        
        // Consumer 벤치마크 (Protobuf 역직렬화 제외)
        val consumerTime = if (serializer.name != "Protobuf") {
            runConsumerBenchmark(topicName, messages.size, serializer)
        } else {
            runConsumerBenchmarkRaw(topicName, messages.size)
        }
        
        return KafkaBenchmarkResult(
            serializerName = serializer.name,
            messageCount = messages.size,
            payloadSize = payloadSize,
            producerTimeMs = producerTime,
            consumerTimeMs = consumerTime,
            totalBytesProduced = totalBytes,
            producerThroughput = messages.size.toDouble() / (producerTime / 1000.0),
            consumerThroughput = messages.size.toDouble() / (consumerTime / 1000.0),
            producerBandwidth = (totalBytes / 1_000_000.0) / (producerTime / 1000.0),
            consumerBandwidth = (totalBytes / 1_000_000.0) / (consumerTime / 1000.0)
        )
    }
    
    private fun runProducerBenchmark(topicName: String, messages: List<ByteArray>): Long {
        val props = Properties().apply {
            put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
            put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer::class.java.name)
            put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer::class.java.name)
            put(ProducerConfig.ACKS_CONFIG, "all")
            put(ProducerConfig.BATCH_SIZE_CONFIG, 16384)
            put(ProducerConfig.LINGER_MS_CONFIG, 1)
            put(ProducerConfig.BUFFER_MEMORY_CONFIG, 33554432)
        }
        
        val producer = KafkaProducer<String, ByteArray>(props)
        
        val startTime = System.currentTimeMillis()
        
        for ((index, data) in messages.withIndex()) {
            val record = ProducerRecord(topicName, "key-$index", data)
            producer.send(record)
        }
        producer.flush()
        
        val endTime = System.currentTimeMillis()
        producer.close()
        
        return endTime - startTime
    }
    
    private fun runConsumerBenchmark(
        topicName: String,
        expectedCount: Int,
        serializer: MessageSerializer
    ): Long {
        val props = Properties().apply {
            put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
            put(ConsumerConfig.GROUP_ID_CONFIG, "benchmark-${UUID.randomUUID()}")
            put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer::class.java.name)
            put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer::class.java.name)
            put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest")
            put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false")
            put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 500)
        }
        
        val consumer = KafkaConsumer<String, ByteArray>(props)
        consumer.subscribe(listOf(topicName))
        
        var consumed = 0
        val startTime = System.currentTimeMillis()
        
        while (consumed < expectedCount) {
            val records = consumer.poll(Duration.ofMillis(1000))
            for (record in records) {
                serializer.deserialize(record.value())
                consumed++
            }
        }
        
        val endTime = System.currentTimeMillis()
        consumer.close()
        
        return endTime - startTime
    }
    
    private fun runConsumerBenchmarkRaw(topicName: String, expectedCount: Int): Long {
        val props = Properties().apply {
            put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers)
            put(ConsumerConfig.GROUP_ID_CONFIG, "benchmark-${UUID.randomUUID()}")
            put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer::class.java.name)
            put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer::class.java.name)
            put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest")
            put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false")
            put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 500)
        }
        
        val consumer = KafkaConsumer<String, ByteArray>(props)
        consumer.subscribe(listOf(topicName))
        
        var consumed = 0
        val startTime = System.currentTimeMillis()
        
        while (consumed < expectedCount) {
            val records = consumer.poll(Duration.ofMillis(1000))
            consumed += records.count()
        }
        
        val endTime = System.currentTimeMillis()
        consumer.close()
        
        return endTime - startTime
    }
    
    private fun printKafkaResult(result: KafkaBenchmarkResult) {
        println("""
            |  Producer 시간: ${result.producerTimeMs} ms
            |  Consumer 시간: ${result.consumerTimeMs} ms
            |  총 데이터: ${result.totalBytesProduced / 1_000_000.0} MB
            |  Producer 처리량: ${String.format("%,.0f", result.producerThroughput)} msg/sec (${String.format("%.2f", result.producerBandwidth)} MB/sec)
            |  Consumer 처리량: ${String.format("%,.0f", result.consumerThroughput)} msg/sec (${String.format("%.2f", result.consumerBandwidth)} MB/sec)
        """.trimMargin())
    }
    
    /**
     * 결과를 CSV로 내보내기
     */
    fun exportToCsv(results: List<KafkaBenchmarkResult>): String {
        val header = "Serializer,MessageCount,PayloadSize,ProducerTimeMs,ConsumerTimeMs,TotalMB,ProducerMsgSec,ConsumerMsgSec,ProducerMBSec,ConsumerMBSec"
        val rows = results.map { r ->
            listOf(
                r.serializerName,
                r.messageCount,
                r.payloadSize,
                r.producerTimeMs,
                r.consumerTimeMs,
                r.totalBytesProduced / 1_000_000.0,
                r.producerThroughput,
                r.consumerThroughput,
                r.producerBandwidth,
                r.consumerBandwidth
            ).joinToString(",")
        }
        return (listOf(header) + rows).joinToString("\n")
    }
}
