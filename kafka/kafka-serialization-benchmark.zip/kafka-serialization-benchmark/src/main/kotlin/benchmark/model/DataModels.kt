package benchmark.model

import com.fasterxml.jackson.annotation.JsonProperty

/**
 * 벤치마크용 메시지 데이터 클래스
 * JSON, JSON Schema, MessagePack에서 공통으로 사용
 */
data class BenchmarkMessage(
    val id: String,
    val timestamp: Long,
    @JsonProperty("event_type")
    val eventType: String,
    val user: UserInfo,
    val device: DeviceInfo,
    val tags: List<String> = emptyList(),
    val metrics: List<Metric> = emptyList(),
    @JsonProperty("session_id")
    val sessionId: String? = null,
    @JsonProperty("correlation_id")
    val correlationId: String? = null,
    val metadata: Map<String, String> = emptyMap(),
    val payload: ByteArray = ByteArray(0)
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as BenchmarkMessage
        return id == other.id && timestamp == other.timestamp
    }

    override fun hashCode(): Int = 31 * id.hashCode() + timestamp.hashCode()
}

data class UserInfo(
    @JsonProperty("user_id")
    val userId: String,
    val username: String,
    val email: String,
    val age: Int,
    val country: String,
    val roles: List<String> = emptyList()
)

data class DeviceInfo(
    @JsonProperty("device_id")
    val deviceId: String,
    @JsonProperty("device_type")
    val deviceType: String,
    @JsonProperty("os_name")
    val osName: String,
    @JsonProperty("os_version")
    val osVersion: String,
    @JsonProperty("app_version")
    val appVersion: String,
    val latitude: Double,
    val longitude: Double
)

data class Metric(
    val name: String,
    val value: Double,
    val unit: String,
    @JsonProperty("recorded_at")
    val recordedAt: Long
)
