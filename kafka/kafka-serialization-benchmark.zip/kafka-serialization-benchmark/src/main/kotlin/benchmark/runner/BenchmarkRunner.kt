package benchmark.runner

import benchmark.generator.TestDataGenerator
import benchmark.model.BenchmarkMessage
import benchmark.serializer.*
import java.text.DecimalFormat
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/**
 * 직렬화 포맷별 벤치마크 결과
 */
data class BenchmarkResult(
    val serializerName: String,
    val messageCount: Int,
    val payloadSize: Int,
    val serializationTimeNs: Long,
    val deserializationTimeNs: Long,
    val totalSerializedBytes: Long,
    val avgSerializedSize: Double,
    val minSerializedSize: Int,
    val maxSerializedSize: Int,
    val serializationThroughput: Double, // messages/sec
    val deserializationThroughput: Double // messages/sec
)

/**
 * 벤치마크 실행기
 */
class BenchmarkRunner(
    private val warmupIterations: Int = 1000,
    private val measurementIterations: Int = 10
) {
    private val numberFormat = DecimalFormat("#,###")
    private val decimalFormat = DecimalFormat("#,###.##")
    
    /**
     * 모든 직렬화 포맷에 대해 벤치마크 실행
     */
    fun runFullBenchmark(
        messageCounts: List<Int> = listOf(1000, 10000, 100000),
        payloadSizes: List<Int> = listOf(100, 1000, 10000)
    ): List<BenchmarkResult> {
        val serializers = listOf(
            JsonSerializer(),
            MessagePackSerializer(),
            AvroSerializer(),
            ProtobufSerializer()
        )
        
        val results = mutableListOf<BenchmarkResult>()
        
        println("=" .repeat(80))
        println("Kafka 직렬화 포맷 벤치마크")
        println("=" .repeat(80))
        println("워밍업 반복: $warmupIterations, 측정 반복: $measurementIterations")
        println()
        
        for (payloadSize in payloadSizes) {
            for (messageCount in messageCounts) {
                println("-".repeat(80))
                println("테스트 설정: 메시지 수=${numberFormat.format(messageCount)}, 페이로드=${numberFormat.format(payloadSize)} bytes")
                println("-".repeat(80))
                
                // 테스트 데이터 생성
                print("테스트 데이터 생성 중...")
                val messages = TestDataGenerator.generateMessages(messageCount, payloadSize)
                println(" 완료!")
                
                for (serializer in serializers) {
                    try {
                        val result = runBenchmark(serializer, messages, payloadSize)
                        results.add(result)
                        printResult(result)
                    } catch (e: Exception) {
                        println("${serializer.name}: 오류 발생 - ${e.message}")
                    }
                }
                println()
            }
        }
        
        return results
    }
    
    /**
     * 단일 직렬화 포맷 벤치마크
     */
    fun runBenchmark(
        serializer: MessageSerializer,
        messages: List<BenchmarkMessage>,
        payloadSize: Int
    ): BenchmarkResult {
        // 워밍업
        warmup(serializer, messages.take(warmupIterations.coerceAtMost(messages.size)))
        
        // 측정 실행
        val serializedDataList = mutableListOf<ByteArray>()
        val serializationTimes = mutableListOf<Long>()
        val deserializationTimes = mutableListOf<Long>()
        
        repeat(measurementIterations) {
            // 직렬화 측정
            serializedDataList.clear()
            val serStart = System.nanoTime()
            for (message in messages) {
                serializedDataList.add(serializer.serialize(message))
            }
            val serEnd = System.nanoTime()
            serializationTimes.add(serEnd - serStart)
            
            // 역직렬화 측정 (Protobuf는 제외)
            if (serializer.name != "Protobuf") {
                val deserStart = System.nanoTime()
                for (data in serializedDataList) {
                    serializer.deserialize(data)
                }
                val deserEnd = System.nanoTime()
                deserializationTimes.add(deserEnd - deserStart)
            }
        }
        
        val avgSerializationTime = serializationTimes.average().toLong()
        val avgDeserializationTime = if (deserializationTimes.isNotEmpty()) 
            deserializationTimes.average().toLong() else 0L
        
        val sizes = serializedDataList.map { it.size }
        val totalBytes = sizes.sumOf { it.toLong() }
        
        return BenchmarkResult(
            serializerName = serializer.name,
            messageCount = messages.size,
            payloadSize = payloadSize,
            serializationTimeNs = avgSerializationTime,
            deserializationTimeNs = avgDeserializationTime,
            totalSerializedBytes = totalBytes,
            avgSerializedSize = sizes.average(),
            minSerializedSize = sizes.minOrNull() ?: 0,
            maxSerializedSize = sizes.maxOrNull() ?: 0,
            serializationThroughput = messages.size.toDouble() / (avgSerializationTime / 1_000_000_000.0),
            deserializationThroughput = if (avgDeserializationTime > 0) 
                messages.size.toDouble() / (avgDeserializationTime / 1_000_000_000.0) else 0.0
        )
    }
    
    private fun warmup(serializer: MessageSerializer, messages: List<BenchmarkMessage>) {
        for (message in messages) {
            val data = serializer.serialize(message)
            if (serializer.name != "Protobuf") {
                serializer.deserialize(data)
            }
        }
    }
    
    private fun printResult(result: BenchmarkResult) {
        val serTimeMs = result.serializationTimeNs / 1_000_000.0
        val deserTimeMs = result.deserializationTimeNs / 1_000_000.0
        
        println("""
            |  ${result.serializerName}:
            |    직렬화 시간: ${decimalFormat.format(serTimeMs)} ms
            |    역직렬화 시간: ${if (result.deserializationTimeNs > 0) "${decimalFormat.format(deserTimeMs)} ms" else "N/A"}
            |    평균 메시지 크기: ${decimalFormat.format(result.avgSerializedSize)} bytes
            |    총 직렬화 크기: ${numberFormat.format(result.totalSerializedBytes)} bytes
            |    직렬화 처리량: ${numberFormat.format(result.serializationThroughput.toLong())} msg/sec
            |    역직렬화 처리량: ${if (result.deserializationThroughput > 0) "${numberFormat.format(result.deserializationThroughput.toLong())} msg/sec" else "N/A"}
        """.trimMargin())
    }
    
    /**
     * 결과를 CSV 형식으로 출력
     */
    fun exportToCsv(results: List<BenchmarkResult>): String {
        val header = "Serializer,MessageCount,PayloadSize,SerTimeMs,DeserTimeMs,AvgMsgSize,TotalBytes,SerThroughput,DeserThroughput"
        val rows = results.map { r ->
            listOf(
                r.serializerName,
                r.messageCount,
                r.payloadSize,
                r.serializationTimeNs / 1_000_000.0,
                r.deserializationTimeNs / 1_000_000.0,
                r.avgSerializedSize,
                r.totalSerializedBytes,
                r.serializationThroughput,
                r.deserializationThroughput
            ).joinToString(",")
        }
        return (listOf(header) + rows).joinToString("\n")
    }
    
    /**
     * 결과 요약 리포트 생성
     */
    fun generateSummaryReport(results: List<BenchmarkResult>): String {
        val sb = StringBuilder()
        sb.appendLine("=" .repeat(80))
        sb.appendLine("벤치마크 요약 리포트")
        sb.appendLine("=" .repeat(80))
        sb.appendLine()
        
        // 포맷별 그룹화
        val bySerializer = results.groupBy { it.serializerName }
        
        // JSON을 기준으로 상대 성능 계산
        val jsonResults = bySerializer["JSON"] ?: return "JSON 결과 없음"
        
        for ((name, serializerResults) in bySerializer) {
            sb.appendLine("[$name]")
            
            for (result in serializerResults) {
                val jsonResult = jsonResults.find { 
                    it.messageCount == result.messageCount && it.payloadSize == result.payloadSize 
                }
                
                if (jsonResult != null) {
                    val serSpeedup = jsonResult.serializationTimeNs.toDouble() / result.serializationTimeNs
                    val sizeRatio = result.avgSerializedSize / jsonResult.avgSerializedSize * 100
                    
                    sb.appendLine("  ${result.messageCount}개 / ${result.payloadSize}B payload:")
                    sb.appendLine("    - 직렬화 속도: ${decimalFormat.format(serSpeedup)}x (JSON 대비)")
                    sb.appendLine("    - 메시지 크기: ${decimalFormat.format(sizeRatio)}% (JSON 대비)")
                }
            }
            sb.appendLine()
        }
        
        return sb.toString()
    }
}
