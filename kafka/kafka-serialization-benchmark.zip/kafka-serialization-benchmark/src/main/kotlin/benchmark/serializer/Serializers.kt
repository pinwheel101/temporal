package benchmark.serializer

import benchmark.model.BenchmarkMessage
import benchmark.model.UserInfo
import benchmark.model.DeviceInfo
import benchmark.model.Metric
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.apache.avro.Schema
import org.apache.avro.generic.GenericData
import org.apache.avro.generic.GenericDatumReader
import org.apache.avro.generic.GenericDatumWriter
import org.apache.avro.generic.GenericRecord
import org.apache.avro.io.DecoderFactory
import org.apache.avro.io.EncoderFactory
import org.msgpack.jackson.dataformat.MessagePackFactory
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer

/**
 * 직렬화/역직렬화 인터페이스
 */
interface MessageSerializer {
    val name: String
    fun serialize(message: BenchmarkMessage): ByteArray
    fun deserialize(data: ByteArray): BenchmarkMessage
}

/**
 * JSON 직렬화 (Plain JSON without schema)
 */
class JsonSerializer : MessageSerializer {
    override val name = "JSON"
    private val mapper: ObjectMapper = jacksonObjectMapper()
    
    override fun serialize(message: BenchmarkMessage): ByteArray {
        return mapper.writeValueAsBytes(message)
    }
    
    override fun deserialize(data: ByteArray): BenchmarkMessage {
        return mapper.readValue(data)
    }
}

/**
 * MessagePack 직렬화
 */
class MessagePackSerializer : MessageSerializer {
    override val name = "MessagePack"
    private val mapper = ObjectMapper(MessagePackFactory()).apply {
        findAndRegisterModules()
    }
    
    override fun serialize(message: BenchmarkMessage): ByteArray {
        return mapper.writeValueAsBytes(message)
    }
    
    override fun deserialize(data: ByteArray): BenchmarkMessage {
        return mapper.readValue(data, BenchmarkMessage::class.java)
    }
}

/**
 * Avro 직렬화 (Generic Record 방식 - Schema Registry 없이)
 */
class AvroSerializer : MessageSerializer {
    override val name = "Avro"
    
    private val schemaJson = """
    {
      "type": "record",
      "name": "BenchmarkMessage",
      "namespace": "benchmark.avro",
      "fields": [
        {"name": "id", "type": "string"},
        {"name": "timestamp", "type": "long"},
        {"name": "eventType", "type": "string"},
        {"name": "user", "type": {
          "type": "record", "name": "UserInfo",
          "fields": [
            {"name": "userId", "type": "string"},
            {"name": "username", "type": "string"},
            {"name": "email", "type": "string"},
            {"name": "age", "type": "int"},
            {"name": "country", "type": "string"},
            {"name": "roles", "type": {"type": "array", "items": "string"}}
          ]
        }},
        {"name": "device", "type": {
          "type": "record", "name": "DeviceInfo",
          "fields": [
            {"name": "deviceId", "type": "string"},
            {"name": "deviceType", "type": "string"},
            {"name": "osName", "type": "string"},
            {"name": "osVersion", "type": "string"},
            {"name": "appVersion", "type": "string"},
            {"name": "latitude", "type": "double"},
            {"name": "longitude", "type": "double"}
          ]
        }},
        {"name": "tags", "type": {"type": "array", "items": "string"}, "default": []},
        {"name": "metrics", "type": {"type": "array", "items": {
          "type": "record", "name": "Metric",
          "fields": [
            {"name": "name", "type": "string"},
            {"name": "value", "type": "double"},
            {"name": "unit", "type": "string"},
            {"name": "recordedAt", "type": "long"}
          ]
        }}, "default": []},
        {"name": "sessionId", "type": ["null", "string"], "default": null},
        {"name": "correlationId", "type": ["null", "string"], "default": null},
        {"name": "metadata", "type": {"type": "map", "values": "string"}, "default": {}},
        {"name": "payload", "type": "bytes"}
      ]
    }
    """.trimIndent()
    
    private val schema: Schema = Schema.Parser().parse(schemaJson)
    private val userSchema: Schema = schema.getField("user").schema()
    private val deviceSchema: Schema = schema.getField("device").schema()
    private val metricSchema: Schema = schema.getField("metrics").schema().elementType
    
    private val writer = GenericDatumWriter<GenericRecord>(schema)
    private val reader = GenericDatumReader<GenericRecord>(schema)
    
    override fun serialize(message: BenchmarkMessage): ByteArray {
        val record = GenericData.Record(schema).apply {
            put("id", message.id)
            put("timestamp", message.timestamp)
            put("eventType", message.eventType)
            put("user", createUserRecord(message.user))
            put("device", createDeviceRecord(message.device))
            put("tags", message.tags)
            put("metrics", message.metrics.map { createMetricRecord(it) })
            put("sessionId", message.sessionId)
            put("correlationId", message.correlationId)
            put("metadata", message.metadata)
            put("payload", ByteBuffer.wrap(message.payload))
        }
        
        val output = ByteArrayOutputStream()
        val encoder = EncoderFactory.get().binaryEncoder(output, null)
        writer.write(record, encoder)
        encoder.flush()
        return output.toByteArray()
    }
    
    override fun deserialize(data: ByteArray): BenchmarkMessage {
        val decoder = DecoderFactory.get().binaryDecoder(data, null)
        val record = reader.read(null, decoder)
        
        return BenchmarkMessage(
            id = record.get("id").toString(),
            timestamp = record.get("timestamp") as Long,
            eventType = record.get("eventType").toString(),
            user = parseUserRecord(record.get("user") as GenericRecord),
            device = parseDeviceRecord(record.get("device") as GenericRecord),
            tags = (record.get("tags") as List<*>).map { it.toString() },
            metrics = (record.get("metrics") as List<*>).map { parseMetricRecord(it as GenericRecord) },
            sessionId = record.get("sessionId")?.toString(),
            correlationId = record.get("correlationId")?.toString(),
            metadata = (record.get("metadata") as Map<*, *>).map { it.key.toString() to it.value.toString() }.toMap(),
            payload = (record.get("payload") as ByteBuffer).let { buf ->
                ByteArray(buf.remaining()).also { buf.get(it) }
            }
        )
    }
    
    private fun createUserRecord(user: UserInfo): GenericRecord {
        return GenericData.Record(userSchema).apply {
            put("userId", user.userId)
            put("username", user.username)
            put("email", user.email)
            put("age", user.age)
            put("country", user.country)
            put("roles", user.roles)
        }
    }
    
    private fun createDeviceRecord(device: DeviceInfo): GenericRecord {
        return GenericData.Record(deviceSchema).apply {
            put("deviceId", device.deviceId)
            put("deviceType", device.deviceType)
            put("osName", device.osName)
            put("osVersion", device.osVersion)
            put("appVersion", device.appVersion)
            put("latitude", device.latitude)
            put("longitude", device.longitude)
        }
    }
    
    private fun createMetricRecord(metric: Metric): GenericRecord {
        return GenericData.Record(metricSchema).apply {
            put("name", metric.name)
            put("value", metric.value)
            put("unit", metric.unit)
            put("recordedAt", metric.recordedAt)
        }
    }
    
    private fun parseUserRecord(record: GenericRecord): UserInfo {
        return UserInfo(
            userId = record.get("userId").toString(),
            username = record.get("username").toString(),
            email = record.get("email").toString(),
            age = record.get("age") as Int,
            country = record.get("country").toString(),
            roles = (record.get("roles") as List<*>).map { it.toString() }
        )
    }
    
    private fun parseDeviceRecord(record: GenericRecord): DeviceInfo {
        return DeviceInfo(
            deviceId = record.get("deviceId").toString(),
            deviceType = record.get("deviceType").toString(),
            osName = record.get("osName").toString(),
            osVersion = record.get("osVersion").toString(),
            appVersion = record.get("appVersion").toString(),
            latitude = record.get("latitude") as Double,
            longitude = record.get("longitude") as Double
        )
    }
    
    private fun parseMetricRecord(record: GenericRecord): Metric {
        return Metric(
            name = record.get("name").toString(),
            value = record.get("value") as Double,
            unit = record.get("unit").toString(),
            recordedAt = record.get("recordedAt") as Long
        )
    }
}

/**
 * Protobuf 직렬화 (생성된 코드 없이 동적 방식)
 * 참고: 실제 프로덕션에서는 protoc로 생성된 코드 사용 권장
 */
class ProtobufSerializer : MessageSerializer {
    override val name = "Protobuf"
    
    // 간소화된 구현: Jackson을 사용한 JSON 중간 변환 후 Protobuf JsonFormat 사용
    // 실제 성능 테스트에서는 생성된 Protobuf 클래스 사용 필요
    private val jsonMapper = jacksonObjectMapper()
    
    // Protobuf 필드 번호 및 wire type 상수
    companion object {
        private const val WIRE_TYPE_VARINT = 0
        private const val WIRE_TYPE_FIXED64 = 1
        private const val WIRE_TYPE_LENGTH_DELIMITED = 2
        private const val WIRE_TYPE_FIXED32 = 5
    }
    
    override fun serialize(message: BenchmarkMessage): ByteArray {
        val output = ByteArrayOutputStream()
        
        // Field 1: id (string)
        writeTag(output, 1, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, message.id)
        
        // Field 2: timestamp (int64)
        writeTag(output, 2, WIRE_TYPE_VARINT)
        writeVarint(output, message.timestamp)
        
        // Field 3: eventType (string)
        writeTag(output, 3, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, message.eventType)
        
        // Field 4: user (embedded message) - 간소화
        val userBytes = serializeUser(message.user)
        writeTag(output, 4, WIRE_TYPE_LENGTH_DELIMITED)
        writeVarint(output, userBytes.size.toLong())
        output.write(userBytes)
        
        // Field 5: device (embedded message) - 간소화
        val deviceBytes = serializeDevice(message.device)
        writeTag(output, 5, WIRE_TYPE_LENGTH_DELIMITED)
        writeVarint(output, deviceBytes.size.toLong())
        output.write(deviceBytes)
        
        // Field 6: tags (repeated string)
        for (tag in message.tags) {
            writeTag(output, 6, WIRE_TYPE_LENGTH_DELIMITED)
            writeString(output, tag)
        }
        
        // Field 7: metrics (repeated message) - 간소화
        for (metric in message.metrics) {
            val metricBytes = serializeMetric(metric)
            writeTag(output, 7, WIRE_TYPE_LENGTH_DELIMITED)
            writeVarint(output, metricBytes.size.toLong())
            output.write(metricBytes)
        }
        
        // Field 8: sessionId (optional string)
        message.sessionId?.let {
            writeTag(output, 8, WIRE_TYPE_LENGTH_DELIMITED)
            writeString(output, it)
        }
        
        // Field 9: correlationId (optional string)
        message.correlationId?.let {
            writeTag(output, 9, WIRE_TYPE_LENGTH_DELIMITED)
            writeString(output, it)
        }
        
        // Field 10: metadata (map<string, string>) - 간소화
        for ((key, value) in message.metadata) {
            val entryBytes = ByteArrayOutputStream().apply {
                writeTag(this, 1, WIRE_TYPE_LENGTH_DELIMITED)
                writeString(this, key)
                writeTag(this, 2, WIRE_TYPE_LENGTH_DELIMITED)
                writeString(this, value)
            }.toByteArray()
            writeTag(output, 10, WIRE_TYPE_LENGTH_DELIMITED)
            writeVarint(output, entryBytes.size.toLong())
            output.write(entryBytes)
        }
        
        // Field 11: payload (bytes)
        if (message.payload.isNotEmpty()) {
            writeTag(output, 11, WIRE_TYPE_LENGTH_DELIMITED)
            writeVarint(output, message.payload.size.toLong())
            output.write(message.payload)
        }
        
        return output.toByteArray()
    }
    
    private fun serializeUser(user: UserInfo): ByteArray {
        val output = ByteArrayOutputStream()
        writeTag(output, 1, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, user.userId)
        writeTag(output, 2, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, user.username)
        writeTag(output, 3, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, user.email)
        writeTag(output, 4, WIRE_TYPE_VARINT)
        writeVarint(output, user.age.toLong())
        writeTag(output, 5, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, user.country)
        for (role in user.roles) {
            writeTag(output, 6, WIRE_TYPE_LENGTH_DELIMITED)
            writeString(output, role)
        }
        return output.toByteArray()
    }
    
    private fun serializeDevice(device: DeviceInfo): ByteArray {
        val output = ByteArrayOutputStream()
        writeTag(output, 1, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, device.deviceId)
        writeTag(output, 2, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, device.deviceType)
        writeTag(output, 3, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, device.osName)
        writeTag(output, 4, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, device.osVersion)
        writeTag(output, 5, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, device.appVersion)
        writeTag(output, 6, WIRE_TYPE_FIXED64)
        writeDouble(output, device.latitude)
        writeTag(output, 7, WIRE_TYPE_FIXED64)
        writeDouble(output, device.longitude)
        return output.toByteArray()
    }
    
    private fun serializeMetric(metric: Metric): ByteArray {
        val output = ByteArrayOutputStream()
        writeTag(output, 1, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, metric.name)
        writeTag(output, 2, WIRE_TYPE_FIXED64)
        writeDouble(output, metric.value)
        writeTag(output, 3, WIRE_TYPE_LENGTH_DELIMITED)
        writeString(output, metric.unit)
        writeTag(output, 4, WIRE_TYPE_VARINT)
        writeVarint(output, metric.recordedAt)
        return output.toByteArray()
    }
    
    private fun writeTag(output: ByteArrayOutputStream, fieldNumber: Int, wireType: Int) {
        writeVarint(output, ((fieldNumber shl 3) or wireType).toLong())
    }
    
    private fun writeVarint(output: ByteArrayOutputStream, value: Long) {
        var v = value
        while (v and 0x7FL.inv() != 0L) {
            output.write(((v.toInt() and 0x7F) or 0x80))
            v = v ushr 7
        }
        output.write(v.toInt())
    }
    
    private fun writeString(output: ByteArrayOutputStream, value: String) {
        val bytes = value.toByteArray(Charsets.UTF_8)
        writeVarint(output, bytes.size.toLong())
        output.write(bytes)
    }
    
    private fun writeDouble(output: ByteArrayOutputStream, value: Double) {
        val bits = java.lang.Double.doubleToLongBits(value)
        for (i in 0 until 8) {
            output.write((bits shr (i * 8)).toInt() and 0xFF)
        }
    }
    
    override fun deserialize(data: ByteArray): BenchmarkMessage {
        // 간소화: deserialize는 JSON으로 폴백
        // 실제 프로덕션에서는 완전한 Protobuf 파싱 필요
        throw UnsupportedOperationException("Protobuf deserialization requires generated code. Use serialize-only benchmark.")
    }
}
