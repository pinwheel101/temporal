package benchmark.generator

import benchmark.model.*
import java.util.UUID
import kotlin.random.Random

/**
 * 벤치마크용 테스트 데이터 생성기
 */
object TestDataGenerator {
    
    private val eventTypes = listOf(
        "user.login", "user.logout", "user.signup",
        "order.created", "order.updated", "order.completed",
        "payment.initiated", "payment.completed", "payment.failed",
        "item.viewed", "item.added_to_cart", "item.purchased"
    )
    
    private val countries = listOf("KR", "US", "JP", "CN", "DE", "FR", "GB", "AU")
    private val deviceTypes = listOf("mobile", "tablet", "desktop", "tv", "iot")
    private val osNames = listOf("Android", "iOS", "Windows", "macOS", "Linux")
    private val roles = listOf("user", "admin", "moderator", "guest", "premium")
    private val tags = listOf("important", "urgent", "low-priority", "archived", "featured", "new")
    private val metricNames = listOf("cpu_usage", "memory_usage", "response_time", "error_rate", "throughput")
    private val units = listOf("percent", "bytes", "ms", "count", "ops/sec")
    
    /**
     * 단일 벤치마크 메시지 생성
     * @param payloadSize 페이로드 크기 (bytes)
     */
    fun generateMessage(payloadSize: Int = 100): BenchmarkMessage {
        val now = System.currentTimeMillis()
        
        return BenchmarkMessage(
            id = UUID.randomUUID().toString(),
            timestamp = now,
            eventType = eventTypes.random(),
            user = generateUserInfo(),
            device = generateDeviceInfo(),
            tags = generateTags(),
            metrics = generateMetrics(now),
            sessionId = if (Random.nextBoolean()) UUID.randomUUID().toString() else null,
            correlationId = if (Random.nextBoolean()) UUID.randomUUID().toString() else null,
            metadata = generateMetadata(),
            payload = Random.nextBytes(payloadSize)
        )
    }
    
    /**
     * 여러 메시지 일괄 생성
     */
    fun generateMessages(count: Int, payloadSize: Int = 100): List<BenchmarkMessage> {
        return (1..count).map { generateMessage(payloadSize) }
    }
    
    private fun generateUserInfo(): UserInfo {
        val userId = "user_${Random.nextInt(1000000)}"
        return UserInfo(
            userId = userId,
            username = "user_${Random.nextInt(10000)}",
            email = "$userId@example.com",
            age = Random.nextInt(18, 80),
            country = countries.random(),
            roles = roles.shuffled().take(Random.nextInt(1, 4))
        )
    }
    
    private fun generateDeviceInfo(): DeviceInfo {
        return DeviceInfo(
            deviceId = UUID.randomUUID().toString(),
            deviceType = deviceTypes.random(),
            osName = osNames.random(),
            osVersion = "${Random.nextInt(10, 20)}.${Random.nextInt(0, 10)}.${Random.nextInt(0, 10)}",
            appVersion = "${Random.nextInt(1, 10)}.${Random.nextInt(0, 100)}.${Random.nextInt(0, 1000)}",
            latitude = Random.nextDouble(-90.0, 90.0),
            longitude = Random.nextDouble(-180.0, 180.0)
        )
    }
    
    private fun generateTags(): List<String> {
        return tags.shuffled().take(Random.nextInt(0, 4))
    }
    
    private fun generateMetrics(baseTime: Long): List<Metric> {
        return (0 until Random.nextInt(1, 6)).map { i ->
            Metric(
                name = metricNames.random(),
                value = Random.nextDouble(0.0, 100.0),
                unit = units.random(),
                recordedAt = baseTime - (i * 1000L)
            )
        }
    }
    
    private fun generateMetadata(): Map<String, String> {
        val keys = listOf("source", "version", "environment", "region", "cluster")
        val values = listOf("production", "staging", "development", "us-east-1", "eu-west-1", "ap-northeast-2")
        
        return keys.shuffled()
            .take(Random.nextInt(0, 4))
            .associateWith { values.random() }
    }
}
