package benchmark

import benchmark.kafka.KafkaBenchmark
import benchmark.runner.BenchmarkRunner
import java.io.File

/**
 * Kafka 직렬화 포맷 벤치마크 메인 클래스
 * 
 * 사용법:
 *   # 로컬 직렬화만 테스트 (Kafka 없이)
 *   java -jar benchmark.jar local
 *   
 *   # Kafka 통합 테스트
 *   java -jar benchmark.jar kafka <bootstrap-servers>
 *   
 *   # 전체 테스트
 *   java -jar benchmark.jar all <bootstrap-servers>
 */
fun main(args: Array<String>) {
    val mode = args.getOrElse(0) { "local" }
    val bootstrapServers = args.getOrElse(1) { "localhost:9092" }
    
    println("""
        |
        |╔══════════════════════════════════════════════════════════════════════════════╗
        |║          Kafka 직렬화 포맷 벤치마크 (Protobuf vs Avro vs JSON)               ║
        |╚══════════════════════════════════════════════════════════════════════════════╝
        |
        |모드: $mode
        |Bootstrap Servers: $bootstrapServers
        |
    """.trimMargin())
    
    when (mode.lowercase()) {
        "local" -> runLocalBenchmark()
        "kafka" -> runKafkaBenchmark(bootstrapServers)
        "all" -> {
            runLocalBenchmark()
            println("\n\n")
            runKafkaBenchmark(bootstrapServers)
        }
        "quick" -> runQuickBenchmark()
        else -> {
            println("사용법: java -jar benchmark.jar [local|kafka|all|quick] [bootstrap-servers]")
            println()
            println("모드:")
            println("  local  - 로컬 직렬화/역직렬화 벤치마크 (Kafka 없이)")
            println("  kafka  - Kafka Producer/Consumer 통합 벤치마크")
            println("  all    - 모든 벤치마크 실행")
            println("  quick  - 빠른 테스트 (소량 메시지)")
        }
    }
}

/**
 * 로컬 직렬화 벤치마크 (Kafka 없이)
 */
fun runLocalBenchmark() {
    println("▶ 로컬 직렬화 벤치마크 시작")
    println()
    
    val runner = BenchmarkRunner(
        warmupIterations = 1000,
        measurementIterations = 5
    )
    
    val results = runner.runFullBenchmark(
        messageCounts = listOf(10000, 100000),
        payloadSizes = listOf(100, 1000, 5000)
    )
    
    // 요약 리포트 출력
    println(runner.generateSummaryReport(results))
    
    // CSV 저장
    val csvContent = runner.exportToCsv(results)
    File("local_benchmark_results.csv").writeText(csvContent)
    println("결과가 local_benchmark_results.csv에 저장되었습니다.")
}

/**
 * Kafka 통합 벤치마크
 */
fun runKafkaBenchmark(bootstrapServers: String) {
    println("▶ Kafka 통합 벤치마크 시작")
    println()
    
    val benchmark = KafkaBenchmark(
        bootstrapServers = bootstrapServers,
        topicPrefix = "serialization-benchmark"
    )
    
    val results = benchmark.runFullBenchmark(
        messageCount = 100000,
        payloadSizes = listOf(100, 1000, 5000)
    )
    
    // CSV 저장
    val csvContent = benchmark.exportToCsv(results)
    File("kafka_benchmark_results.csv").writeText(csvContent)
    println("\n결과가 kafka_benchmark_results.csv에 저장되었습니다.")
    
    // 요약 출력
    printKafkaSummary(results)
}

/**
 * 빠른 테스트 (검증용)
 */
fun runQuickBenchmark() {
    println("▶ 빠른 검증 테스트")
    println()
    
    val runner = BenchmarkRunner(
        warmupIterations = 100,
        measurementIterations = 3
    )
    
    val results = runner.runFullBenchmark(
        messageCounts = listOf(1000),
        payloadSizes = listOf(100)
    )
    
    println(runner.generateSummaryReport(results))
}

fun printKafkaSummary(results: List<benchmark.kafka.KafkaBenchmarkResult>) {
    println()
    println("=" .repeat(80))
    println("Kafka 벤치마크 요약")
    println("=" .repeat(80))
    
    val byPayload = results.groupBy { it.payloadSize }
    
    for ((payloadSize, payloadResults) in byPayload) {
        println("\n페이로드: $payloadSize bytes")
        println("-".repeat(40))
        
        val jsonResult = payloadResults.find { it.serializerName == "JSON" }
        
        for (result in payloadResults) {
            print("  ${result.serializerName.padEnd(12)}")
            
            if (jsonResult != null) {
                val speedup = jsonResult.producerTimeMs.toDouble() / result.producerTimeMs
                val sizeRatio = result.totalBytesProduced.toDouble() / jsonResult.totalBytesProduced * 100
                println(" | ${String.format("%.2f", speedup)}x 빠름 | 크기 ${String.format("%.1f", sizeRatio)}%")
            } else {
                println(" | ${String.format("%,.0f", result.producerThroughput)} msg/sec")
            }
        }
    }
}
