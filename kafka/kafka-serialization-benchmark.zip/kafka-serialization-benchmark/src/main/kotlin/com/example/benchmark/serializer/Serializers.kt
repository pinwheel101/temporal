package com.example.benchmark.serializer

import com.example.benchmark.model.*
import com.example.benchmark.proto.BenchmarkProtos
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.apache.avro.Schema
import org.apache.avro.generic.GenericData
import org.apache.avro.generic.GenericDatumReader
import org.apache.avro.generic.GenericDatumWriter
import org.apache.avro.generic.GenericRecord
import org.apache.avro.io.DecoderFactory
import org.apache.avro.io.EncoderFactory
import org.msgpack.jackson.dataformat.MessagePackFactory
import java.io.ByteArrayOutputStream

/**
 * 직렬화 포맷 인터페이스
 */
interface BenchmarkSerializer {
    val name: String
    fun serialize(event: SensorEvent): ByteArray
    fun deserialize(bytes: ByteArray): SensorEvent
}

/**
 * JSON 직렬화 (Jackson)
 */
class JsonSerializer : BenchmarkSerializer {
    override val name = "JSON"
    private val mapper: ObjectMapper = jacksonObjectMapper()
    
    override fun serialize(event: SensorEvent): ByteArray {
        return mapper.writeValueAsBytes(event)
    }
    
    override fun deserialize(bytes: ByteArray): SensorEvent {
        return mapper.readValue(bytes)
    }
}

/**
 * JSON 직렬화 (Kotlinx Serialization) - 대안 구현
 */
class KotlinxJsonSerializer : BenchmarkSerializer {
    override val name = "JSON-Kotlinx"
    private val json = Json { 
        ignoreUnknownKeys = true 
        encodeDefaults = true
    }
    
    override fun serialize(event: SensorEvent): ByteArray {
        return json.encodeToString(event).toByteArray(Charsets.UTF_8)
    }
    
    override fun deserialize(bytes: ByteArray): SensorEvent {
        return json.decodeFromString(String(bytes, Charsets.UTF_8))
    }
}

/**
 * Protocol Buffers 직렬화
 */
class ProtobufSerializer : BenchmarkSerializer {
    override val name = "Protobuf"
    
    override fun serialize(event: SensorEvent): ByteArray {
        return toProto(event).toByteArray()
    }
    
    override fun deserialize(bytes: ByteArray): SensorEvent {
        val proto = BenchmarkProtos.SensorEvent.parseFrom(bytes)
        return fromProto(proto)
    }
    
    private fun toProto(event: SensorEvent): BenchmarkProtos.SensorEvent {
        return BenchmarkProtos.SensorEvent.newBuilder()
            .setEventId(event.eventId)
            .setTimestamp(event.timestamp)
            .setDeviceId(event.deviceId)
            .setDeviceType(event.deviceType)
            .setLocation(
                BenchmarkProtos.Location.newBuilder()
                    .setLatitude(event.location.latitude)
                    .setLongitude(event.location.longitude)
                    .setZone(event.location.zone)
                    .setBuilding(event.location.building)
                    .setFloor(event.location.floor)
                    .build()
            )
            .addAllReadings(event.readings.map { reading ->
                BenchmarkProtos.Reading.newBuilder()
                    .setSensorType(reading.sensorType)
                    .setValue(reading.value)
                    .setUnit(reading.unit)
                    .setTimestamp(reading.timestamp)
                    .setQuality(BenchmarkProtos.ReadingQuality.forNumber(reading.quality.ordinal))
                    .build()
            })
            .putAllMetadata(event.metadata)
            .setStatus(BenchmarkProtos.EventStatus.forNumber(event.status.ordinal))
            .build()
    }
    
    private fun fromProto(proto: BenchmarkProtos.SensorEvent): SensorEvent {
        return SensorEvent(
            eventId = proto.eventId,
            timestamp = proto.timestamp,
            deviceId = proto.deviceId,
            deviceType = proto.deviceType,
            location = Location(
                latitude = proto.location.latitude,
                longitude = proto.location.longitude,
                zone = proto.location.zone,
                building = proto.location.building,
                floor = proto.location.floor
            ),
            readings = proto.readingsList.map { reading ->
                Reading(
                    sensorType = reading.sensorType,
                    value = reading.value,
                    unit = reading.unit,
                    timestamp = reading.timestamp,
                    quality = ReadingQuality.entries[reading.qualityValue]
                )
            },
            metadata = proto.metadataMap,
            status = EventStatus.entries[proto.statusValue]
        )
    }
}

/**
 * Apache Avro 직렬화 (Generic Record 방식 - Schema Registry 없이 사용)
 */
class AvroSerializer : BenchmarkSerializer {
    override val name = "Avro"
    
    private val schemaJson = """
    {
      "namespace": "com.example.benchmark.avro",
      "type": "record",
      "name": "SensorEvent",
      "fields": [
        {"name": "eventId", "type": "string"},
        {"name": "timestamp", "type": "long"},
        {"name": "deviceId", "type": "string"},
        {"name": "deviceType", "type": "string"},
        {
          "name": "location",
          "type": {
            "type": "record",
            "name": "Location",
            "fields": [
              {"name": "latitude", "type": "double"},
              {"name": "longitude", "type": "double"},
              {"name": "zone", "type": "string"},
              {"name": "building", "type": "string"},
              {"name": "floor", "type": "int"}
            ]
          }
        },
        {
          "name": "readings",
          "type": {
            "type": "array",
            "items": {
              "type": "record",
              "name": "Reading",
              "fields": [
                {"name": "sensorType", "type": "string"},
                {"name": "value", "type": "double"},
                {"name": "unit", "type": "string"},
                {"name": "timestamp", "type": "long"},
                {
                  "name": "quality",
                  "type": {
                    "type": "enum",
                    "name": "ReadingQuality",
                    "symbols": ["UNKNOWN", "GOOD", "SUSPECT", "BAD"]
                  }
                }
              ]
            }
          }
        },
        {
          "name": "metadata",
          "type": {"type": "map", "values": "string"}
        },
        {
          "name": "status",
          "type": {
            "type": "enum",
            "name": "EventStatus",
            "symbols": ["STATUS_UNKNOWN", "STATUS_NORMAL", "STATUS_WARNING", "STATUS_ALERT", "STATUS_CRITICAL"]
          }
        }
      ]
    }
    """.trimIndent()
    
    private val schema: Schema = Schema.Parser().parse(schemaJson)
    private val locationSchema: Schema = schema.getField("location").schema()
    private val readingSchema: Schema = schema.getField("readings").schema().elementType
    private val qualitySchema: Schema = readingSchema.getField("quality").schema()
    private val statusSchema: Schema = schema.getField("status").schema()
    
    private val writer = GenericDatumWriter<GenericRecord>(schema)
    private val reader = GenericDatumReader<GenericRecord>(schema)
    
    override fun serialize(event: SensorEvent): ByteArray {
        val record = toAvroRecord(event)
        val outputStream = ByteArrayOutputStream()
        val encoder = EncoderFactory.get().binaryEncoder(outputStream, null)
        writer.write(record, encoder)
        encoder.flush()
        return outputStream.toByteArray()
    }
    
    override fun deserialize(bytes: ByteArray): SensorEvent {
        val decoder = DecoderFactory.get().binaryDecoder(bytes, null)
        val record = reader.read(null, decoder)
        return fromAvroRecord(record)
    }
    
    private fun toAvroRecord(event: SensorEvent): GenericRecord {
        val record = GenericData.Record(schema)
        record.put("eventId", event.eventId)
        record.put("timestamp", event.timestamp)
        record.put("deviceId", event.deviceId)
        record.put("deviceType", event.deviceType)
        
        val locationRecord = GenericData.Record(locationSchema)
        locationRecord.put("latitude", event.location.latitude)
        locationRecord.put("longitude", event.location.longitude)
        locationRecord.put("zone", event.location.zone)
        locationRecord.put("building", event.location.building)
        locationRecord.put("floor", event.location.floor)
        record.put("location", locationRecord)
        
        val readings = event.readings.map { reading ->
            val readingRecord = GenericData.Record(readingSchema)
            readingRecord.put("sensorType", reading.sensorType)
            readingRecord.put("value", reading.value)
            readingRecord.put("unit", reading.unit)
            readingRecord.put("timestamp", reading.timestamp)
            readingRecord.put("quality", GenericData.EnumSymbol(qualitySchema, reading.quality.name))
            readingRecord
        }
        record.put("readings", readings)
        
        record.put("metadata", event.metadata)
        record.put("status", GenericData.EnumSymbol(statusSchema, event.status.name))
        
        return record
    }
    
    @Suppress("UNCHECKED_CAST")
    private fun fromAvroRecord(record: GenericRecord): SensorEvent {
        val locationRecord = record.get("location") as GenericRecord
        val readingsArray = record.get("readings") as List<GenericRecord>
        
        return SensorEvent(
            eventId = record.get("eventId").toString(),
            timestamp = record.get("timestamp") as Long,
            deviceId = record.get("deviceId").toString(),
            deviceType = record.get("deviceType").toString(),
            location = Location(
                latitude = locationRecord.get("latitude") as Double,
                longitude = locationRecord.get("longitude") as Double,
                zone = locationRecord.get("zone").toString(),
                building = locationRecord.get("building").toString(),
                floor = locationRecord.get("floor") as Int
            ),
            readings = readingsArray.map { readingRecord ->
                Reading(
                    sensorType = readingRecord.get("sensorType").toString(),
                    value = readingRecord.get("value") as Double,
                    unit = readingRecord.get("unit").toString(),
                    timestamp = readingRecord.get("timestamp") as Long,
                    quality = ReadingQuality.valueOf(readingRecord.get("quality").toString())
                )
            },
            metadata = (record.get("metadata") as Map<CharSequence, CharSequence>)
                .mapKeys { it.key.toString() }
                .mapValues { it.value.toString() },
            status = EventStatus.valueOf(record.get("status").toString())
        )
    }
}

/**
 * MessagePack 직렬화
 */
class MessagePackSerializer : BenchmarkSerializer {
    override val name = "MessagePack"
    private val mapper = ObjectMapper(MessagePackFactory())
        .findAndRegisterModules()
    
    override fun serialize(event: SensorEvent): ByteArray {
        return mapper.writeValueAsBytes(event)
    }
    
    override fun deserialize(bytes: ByteArray): SensorEvent {
        return mapper.readValue(bytes, SensorEvent::class.java)
    }
}

/**
 * 모든 직렬화기 팩토리
 */
object SerializerFactory {
    fun getAll(): List<BenchmarkSerializer> = listOf(
        JsonSerializer(),
        ProtobufSerializer(),
        AvroSerializer(),
        MessagePackSerializer()
    )
    
    fun get(name: String): BenchmarkSerializer? {
        return getAll().find { it.name.equals(name, ignoreCase = true) }
    }
}
