package com.example.benchmark.benchmark

import com.example.benchmark.model.*
import com.example.benchmark.serializer.*
import mu.KotlinLogging
import org.HdrHistogram.Histogram
import java.text.DecimalFormat
import java.util.concurrent.TimeUnit

private val logger = KotlinLogging.logger {}

/**
 * 벤치마크 결과 데이터 클래스
 */
data class BenchmarkResult(
    val serializerName: String,
    val messageSize: MessageSize,
    val messageCount: Int,
    val serializedSizeBytes: Long,
    val serializeTimeNanos: Long,
    val deserializeTimeNanos: Long,
    val serializeHistogram: Histogram,
    val deserializeHistogram: Histogram
) {
    val totalTimeNanos: Long get() = serializeTimeNanos + deserializeTimeNanos
    val serializeThroughput: Double get() = messageCount / (serializeTimeNanos / 1_000_000_000.0)
    val deserializeThroughput: Double get() = messageCount / (deserializeTimeNanos / 1_000_000_000.0)
    val avgSerializedSize: Double get() = serializedSizeBytes.toDouble() / messageCount
}

/**
 * 순수 직렬화/역직렬화 벤치마크 러너 (Kafka 없이 순수 성능 측정)
 */
class PureBenchmarkRunner(
    private val warmupIterations: Int = 1000,
    private val measureIterations: Int = 100_000
) {
    
    /**
     * 모든 직렬화기에 대해 벤치마크 실행
     */
    fun runAll(messageSizes: List<MessageSize> = MessageSize.entries): List<BenchmarkResult> {
        val serializers = SerializerFactory.getAll()
        val results = mutableListOf<BenchmarkResult>()
        
        for (size in messageSizes) {
            logger.info { "===== 메시지 크기: $size =====" }
            
            // 테스트 데이터 생성
            val testEvents = (1..measureIterations).map { TestDataGenerator.generateBySize(size) }
            
            for (serializer in serializers) {
                logger.info { "벤치마크 시작: ${serializer.name}" }
                
                try {
                    val result = runBenchmark(serializer, testEvents, size)
                    results.add(result)
                    printResult(result)
                } catch (e: Exception) {
                    logger.error(e) { "${serializer.name} 벤치마크 실패" }
                }
            }
        }
        
        return results
    }
    
    private fun runBenchmark(
        serializer: BenchmarkSerializer,
        testEvents: List<SensorEvent>,
        messageSize: MessageSize
    ): BenchmarkResult {
        
        // Warmup
        logger.info { "  워밍업 중... ($warmupIterations iterations)" }
        val warmupEvents = testEvents.take(warmupIterations)
        warmupEvents.forEach { event ->
            val bytes = serializer.serialize(event)
            serializer.deserialize(bytes)
        }
        
        // GC 실행 및 안정화
        System.gc()
        Thread.sleep(100)
        
        // 직렬화 측정
        logger.info { "  직렬화 측정 중... ($measureIterations iterations)" }
        val serializeHistogram = Histogram(TimeUnit.SECONDS.toNanos(10), 3)
        val serializedData = mutableListOf<ByteArray>()
        var totalSerializedSize = 0L
        
        val serializeStartTime = System.nanoTime()
        for (event in testEvents) {
            val iterStart = System.nanoTime()
            val bytes = serializer.serialize(event)
            serializeHistogram.recordValue(System.nanoTime() - iterStart)
            serializedData.add(bytes)
            totalSerializedSize += bytes.size
        }
        val serializeEndTime = System.nanoTime()
        
        // 역직렬화 측정
        logger.info { "  역직렬화 측정 중... ($measureIterations iterations)" }
        val deserializeHistogram = Histogram(TimeUnit.SECONDS.toNanos(10), 3)
        
        val deserializeStartTime = System.nanoTime()
        for (bytes in serializedData) {
            val iterStart = System.nanoTime()
            serializer.deserialize(bytes)
            deserializeHistogram.recordValue(System.nanoTime() - iterStart)
        }
        val deserializeEndTime = System.nanoTime()
        
        return BenchmarkResult(
            serializerName = serializer.name,
            messageSize = messageSize,
            messageCount = testEvents.size,
            serializedSizeBytes = totalSerializedSize,
            serializeTimeNanos = serializeEndTime - serializeStartTime,
            deserializeTimeNanos = deserializeEndTime - deserializeStartTime,
            serializeHistogram = serializeHistogram,
            deserializeHistogram = deserializeHistogram
        )
    }
    
    private fun printResult(result: BenchmarkResult) {
        val df = DecimalFormat("#,###.##")
        val timeFormat = DecimalFormat("#,###.###")
        
        println("""
            |
            |  📊 ${result.serializerName} (${result.messageSize})
            |  ─────────────────────────────────────────────
            |  메시지 수: ${df.format(result.messageCount)}
            |  
            |  📦 직렬화 크기
            |     평균: ${df.format(result.avgSerializedSize)} bytes
            |     총합: ${df.format(result.serializedSizeBytes / 1024.0)} KB
            |  
            |  ⏱️ 직렬화 시간
            |     총합: ${timeFormat.format(result.serializeTimeNanos / 1_000_000.0)} ms
            |     평균: ${timeFormat.format(result.serializeHistogram.mean / 1000.0)} μs
            |     p50:  ${timeFormat.format(result.serializeHistogram.getValueAtPercentile(50.0) / 1000.0)} μs
            |     p99:  ${timeFormat.format(result.serializeHistogram.getValueAtPercentile(99.0) / 1000.0)} μs
            |     처리량: ${df.format(result.serializeThroughput)} msgs/sec
            |  
            |  ⏱️ 역직렬화 시간
            |     총합: ${timeFormat.format(result.deserializeTimeNanos / 1_000_000.0)} ms
            |     평균: ${timeFormat.format(result.deserializeHistogram.mean / 1000.0)} μs
            |     p50:  ${timeFormat.format(result.deserializeHistogram.getValueAtPercentile(50.0) / 1000.0)} μs
            |     p99:  ${timeFormat.format(result.deserializeHistogram.getValueAtPercentile(99.0) / 1000.0)} μs
            |     처리량: ${df.format(result.deserializeThroughput)} msgs/sec
            |
        """.trimMargin())
    }
}

/**
 * 벤치마크 결과 비교 리포트 생성
 */
class BenchmarkReporter {
    
    fun generateReport(results: List<BenchmarkResult>): String {
        val sb = StringBuilder()
        
        sb.appendLine("=" .repeat(80))
        sb.appendLine("  KAFKA 직렬화 포맷 벤치마크 결과")
        sb.appendLine("=".repeat(80))
        sb.appendLine()
        
        // 메시지 크기별 그룹핑
        val bySize = results.groupBy { it.messageSize }
        
        for ((size, sizeResults) in bySize) {
            sb.appendLine("━".repeat(80))
            sb.appendLine("  메시지 크기: $size")
            sb.appendLine("━".repeat(80))
            
            // 테이블 헤더
            sb.appendLine(String.format(
                "%-15s %12s %12s %12s %15s %15s",
                "Format", "Avg Size", "Ser. Time", "Deser. Time", "Ser. Thr.", "Deser. Thr."
            ))
            sb.appendLine("-".repeat(80))
            
            // 결과를 직렬화 시간 기준으로 정렬
            val sortedResults = sizeResults.sortedBy { it.serializeTimeNanos }
            
            for (result in sortedResults) {
                sb.appendLine(String.format(
                    "%-15s %10.0f B %10.2f ms %10.2f ms %12.0f/s %12.0f/s",
                    result.serializerName,
                    result.avgSerializedSize,
                    result.serializeTimeNanos / 1_000_000.0,
                    result.deserializeTimeNanos / 1_000_000.0,
                    result.serializeThroughput,
                    result.deserializeThroughput
                ))
            }
            
            // 최고 성능 표시
            val fastest = sortedResults.first()
            val smallest = sizeResults.minByOrNull { it.avgSerializedSize }!!
            
            sb.appendLine()
            sb.appendLine("  🏆 최고 직렬화 속도: ${fastest.serializerName}")
            sb.appendLine("  📦 최소 메시지 크기: ${smallest.serializerName} (${String.format("%.0f", smallest.avgSerializedSize)} bytes)")
            sb.appendLine()
        }
        
        // JSON 대비 개선율 계산
        sb.appendLine("━".repeat(80))
        sb.appendLine("  JSON 대비 성능 비교")
        sb.appendLine("━".repeat(80))
        
        for ((size, sizeResults) in bySize) {
            val jsonResult = sizeResults.find { it.serializerName == "JSON" } ?: continue
            
            sb.appendLine("\n  [$size]")
            for (result in sizeResults.filter { it.serializerName != "JSON" }) {
                val sizeReduction = (1 - result.avgSerializedSize / jsonResult.avgSerializedSize) * 100
                val speedup = jsonResult.serializeTimeNanos.toDouble() / result.serializeTimeNanos
                
                sb.appendLine(String.format(
                    "    %-15s: 크기 %.1f%% 감소, 직렬화 %.1fx 빠름",
                    result.serializerName, sizeReduction, speedup
                ))
            }
        }
        
        sb.appendLine()
        sb.appendLine("=".repeat(80))
        
        return sb.toString()
    }
    
    /**
     * CSV 형식으로 결과 출력
     */
    fun generateCsv(results: List<BenchmarkResult>): String {
        val sb = StringBuilder()
        sb.appendLine("Format,MessageSize,Count,AvgSizeBytes,SerializeMs,DeserializeMs,SerializeThroughput,DeserializeThroughput,SerP50us,SerP99us,DeserP50us,DeserP99us")
        
        for (result in results) {
            sb.appendLine(listOf(
                result.serializerName,
                result.messageSize,
                result.messageCount,
                String.format("%.2f", result.avgSerializedSize),
                String.format("%.2f", result.serializeTimeNanos / 1_000_000.0),
                String.format("%.2f", result.deserializeTimeNanos / 1_000_000.0),
                String.format("%.0f", result.serializeThroughput),
                String.format("%.0f", result.deserializeThroughput),
                String.format("%.2f", result.serializeHistogram.getValueAtPercentile(50.0) / 1000.0),
                String.format("%.2f", result.serializeHistogram.getValueAtPercentile(99.0) / 1000.0),
                String.format("%.2f", result.deserializeHistogram.getValueAtPercentile(50.0) / 1000.0),
                String.format("%.2f", result.deserializeHistogram.getValueAtPercentile(99.0) / 1000.0)
            ).joinToString(","))
        }
        
        return sb.toString()
    }
}
