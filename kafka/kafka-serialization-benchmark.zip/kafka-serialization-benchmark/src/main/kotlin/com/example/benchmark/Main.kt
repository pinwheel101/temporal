package com.example.benchmark

import com.example.benchmark.benchmark.*
import com.example.benchmark.config.*
import com.example.benchmark.model.MessageSize
import com.github.ajalt.clikt.core.CliktCommand
import com.github.ajalt.clikt.core.subcommands
import com.github.ajalt.clikt.parameters.options.*
import com.github.ajalt.clikt.parameters.types.enum
import com.github.ajalt.clikt.parameters.types.int
import mu.KotlinLogging
import java.io.File

private val logger = KotlinLogging.logger {}

/**
 * 메인 CLI 애플리케이션
 */
class BenchmarkCli : CliktCommand(
    name = "kafka-benchmark",
    help = "Kafka 직렬화 포맷 벤치마크 도구"
) {
    override fun run() = Unit
}

/**
 * 순수 직렬화 벤치마크 (Kafka 없이)
 */
class PureBenchmarkCommand : CliktCommand(
    name = "pure",
    help = "순수 직렬화/역직렬화 성능 벤치마크 (Kafka 없이)"
) {
    private val warmup by option("--warmup", "-w", help = "워밍업 반복 횟수")
        .int().default(1000)
    
    private val iterations by option("--iterations", "-n", help = "측정 반복 횟수")
        .int().default(100_000)
    
    private val sizes by option("--size", "-s", help = "테스트할 메시지 크기 (여러 번 지정 가능)")
        .enum<MessageSize>().multiple()
    
    private val outputCsv by option("--output-csv", "-o", help = "CSV 결과 출력 파일")
    
    override fun run() {
        println("""
            |
            |╔══════════════════════════════════════════════════════════════╗
            |║        Kafka 직렬화 포맷 순수 벤치마크                        ║
            |╚══════════════════════════════════════════════════════════════╝
            |
        """.trimMargin())
        
        val messageSizes = sizes.ifEmpty { MessageSize.entries }
        
        logger.info { "설정: warmup=$warmup, iterations=$iterations, sizes=$messageSizes" }
        
        val runner = PureBenchmarkRunner(
            warmupIterations = warmup,
            measureIterations = iterations
        )
        
        val results = runner.runAll(messageSizes)
        
        // 리포트 출력
        val reporter = BenchmarkReporter()
        println(reporter.generateReport(results))
        
        // CSV 저장
        outputCsv?.let { path ->
            File(path).writeText(reporter.generateCsv(results))
            logger.info { "CSV 결과 저장됨: $path" }
        }
    }
}

/**
 * Kafka End-to-End 벤치마크
 */
class KafkaBenchmarkCommand : CliktCommand(
    name = "kafka",
    help = "Kafka 클러스터 End-to-End 벤치마크"
) {
    private val bootstrapServers by option("--bootstrap-servers", "-b", help = "Kafka bootstrap servers")
        .default("localhost:9092")
    
    private val partitions by option("--partitions", "-p", help = "테스트 토픽 파티션 수")
        .int().default(3)
    
    private val replicationFactor by option("--replication-factor", "-r", help = "복제 팩터")
        .int().default(1)
    
    private val warmup by option("--warmup", "-w", help = "워밍업 메시지 수")
        .int().default(100)
    
    private val messages by option("--messages", "-n", help = "측정 메시지 수")
        .int().default(10_000)
    
    private val sizes by option("--size", "-s", help = "테스트할 메시지 크기")
        .enum<MessageSize>().multiple()
    
    private val configFile by option("--config", "-c", help = "Kafka 설정 파일 경로 (client.properties)")
    
    private val outputCsv by option("--output-csv", "-o", help = "CSV 결과 출력 파일")
    
    // TLS 설정
    private val truststore by option("--truststore", help = "SSL truststore 경로")
    private val truststorePassword by option("--truststore-password", help = "SSL truststore 비밀번호")
    
    // SCRAM 인증 설정
    private val username by option("--username", "-u", help = "SASL 사용자명")
    private val password by option("--password", help = "SASL 비밀번호")
    
    override fun run() {
        println("""
            |
            |╔══════════════════════════════════════════════════════════════╗
            |║        Kafka End-to-End 직렬화 포맷 벤치마크                   ║
            |╚══════════════════════════════════════════════════════════════╝
            |
        """.trimMargin())
        
        // 설정 로드
        val kafkaConfig = when {
            configFile != null -> {
                logger.info { "설정 파일에서 로드: $configFile" }
                KafkaConfig.fromPropertiesFile(configFile!!)
            }
            username != null && password != null -> {
                logger.info { "SCRAM 인증 사용" }
                KafkaConfig.strimziScram(
                    bootstrapServers = bootstrapServers,
                    username = username!!,
                    password = password!!,
                    truststorePath = truststore,
                    truststorePassword = truststorePassword,
                    partitions = partitions,
                    replicationFactor = replicationFactor
                )
            }
            truststore != null -> {
                logger.info { "TLS 인증 사용" }
                KafkaConfig.strimziTls(
                    bootstrapServers = bootstrapServers,
                    truststorePath = truststore!!,
                    truststorePassword = truststorePassword ?: "",
                    partitions = partitions,
                    replicationFactor = replicationFactor
                )
            }
            else -> {
                logger.info { "Plain 연결 사용" }
                KafkaConfig.strimziPlain(
                    bootstrapServers = bootstrapServers,
                    partitions = partitions,
                    replicationFactor = replicationFactor
                )
            }
        }
        
        val messageSizes = sizes.ifEmpty { MessageSize.entries }
        
        logger.info { "Bootstrap servers: ${kafkaConfig.bootstrapServers}" }
        logger.info { "설정: warmup=$warmup, messages=$messages, sizes=$messageSizes" }
        
        val runner = KafkaBenchmarkRunner(
            config = kafkaConfig,
            warmupMessages = warmup,
            measureMessages = messages
        )
        
        val results = runner.runAll(messageSizes)
        
        // 리포트 출력
        val reporter = KafkaBenchmarkReporter()
        println(reporter.generateReport(results))
        
        // CSV 저장
        outputCsv?.let { path ->
            File(path).writeText(reporter.generateCsv(results))
            logger.info { "CSV 결과 저장됨: $path" }
        }
    }
}

/**
 * 메시지 크기 검증 명령어
 */
class SizeCheckCommand : CliktCommand(
    name = "size-check",
    help = "각 직렬화 포맷의 메시지 크기 확인"
) {
    override fun run() {
        println("""
            |
            |╔══════════════════════════════════════════════════════════════╗
            |║        직렬화 포맷별 메시지 크기 비교                          ║
            |╚══════════════════════════════════════════════════════════════╝
            |
        """.trimMargin())
        
        val serializers = com.example.benchmark.serializer.SerializerFactory.getAll()
        
        for (size in MessageSize.entries) {
            println("\n📦 메시지 크기: $size")
            println("-".repeat(50))
            
            val event = com.example.benchmark.model.TestDataGenerator.generateBySize(size)
            
            for (serializer in serializers) {
                try {
                    val bytes = serializer.serialize(event)
                    println(String.format("  %-15s: %,8d bytes", serializer.name, bytes.size))
                } catch (e: Exception) {
                    println(String.format("  %-15s: 오류 - %s", serializer.name, e.message))
                }
            }
        }
        println()
    }
}

fun main(args: Array<String>) = BenchmarkCli()
    .subcommands(
        PureBenchmarkCommand(),
        KafkaBenchmarkCommand(),
        SizeCheckCommand()
    )
    .main(args)
