package com.example.benchmark.benchmark

import com.example.benchmark.config.KafkaConfig
import com.example.benchmark.model.*
import com.example.benchmark.serializer.*
import mu.KotlinLogging
import org.apache.kafka.clients.admin.AdminClient
import org.apache.kafka.clients.admin.NewTopic
import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.kafka.clients.consumer.KafkaConsumer
import org.apache.kafka.clients.producer.KafkaProducer
import org.apache.kafka.clients.producer.ProducerConfig
import org.apache.kafka.clients.producer.ProducerRecord
import org.apache.kafka.common.serialization.ByteArrayDeserializer
import org.apache.kafka.common.serialization.ByteArraySerializer
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.kafka.common.serialization.StringSerializer
import org.HdrHistogram.Histogram
import java.time.Duration
import java.util.*
import java.util.concurrent.TimeUnit

private val logger = KotlinLogging.logger {}

/**
 * Kafka End-to-End 벤치마크 결과
 */
data class KafkaBenchmarkResult(
    val serializerName: String,
    val messageSize: MessageSize,
    val messageCount: Int,
    val avgSerializedSizeBytes: Double,
    val produceTimeMs: Long,
    val consumeTimeMs: Long,
    val endToEndTimeMs: Long,
    val produceLatencyHistogram: Histogram,
    val consumeLatencyHistogram: Histogram,
    val produceThroughput: Double,
    val consumeThroughput: Double
)

/**
 * Kafka 클러스터 End-to-End 벤치마크 러너
 */
class KafkaBenchmarkRunner(
    private val config: KafkaConfig,
    private val warmupMessages: Int = 100,
    private val measureMessages: Int = 10_000
) {
    
    /**
     * 모든 직렬화기에 대해 Kafka E2E 벤치마크 실행
     */
    fun runAll(messageSizes: List<MessageSize> = MessageSize.entries): List<KafkaBenchmarkResult> {
        val serializers = SerializerFactory.getAll()
        val results = mutableListOf<KafkaBenchmarkResult>()
        
        for (size in messageSizes) {
            logger.info { "===== Kafka E2E 벤치마크 - 메시지 크기: $size =====" }
            
            for (serializer in serializers) {
                val topicName = "benchmark-${serializer.name.lowercase()}-${size.name.lowercase()}"
                
                try {
                    // 토픽 생성
                    createTopic(topicName)
                    
                    logger.info { "벤치마크 시작: ${serializer.name} on topic $topicName" }
                    val result = runKafkaBenchmark(serializer, topicName, size)
                    results.add(result)
                    printKafkaResult(result)
                    
                } catch (e: Exception) {
                    logger.error(e) { "${serializer.name} Kafka 벤치마크 실패" }
                } finally {
                    // 토픽 삭제 (선택적)
                    // deleteTopic(topicName)
                }
            }
        }
        
        return results
    }
    
    private fun createTopic(topicName: String) {
        val adminProps = Properties().apply {
            put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.bootstrapServers)
            config.securityConfig?.let { putAll(it) }
        }
        
        AdminClient.create(adminProps).use { admin ->
            val existingTopics = admin.listTopics().names().get()
            
            if (topicName !in existingTopics) {
                val newTopic = NewTopic(topicName, config.partitions, config.replicationFactor.toShort())
                admin.createTopics(listOf(newTopic)).all().get()
                logger.info { "토픽 생성됨: $topicName" }
                Thread.sleep(1000) // 토픽 생성 대기
            } else {
                logger.info { "기존 토픽 사용: $topicName" }
            }
        }
    }
    
    private fun runKafkaBenchmark(
        serializer: BenchmarkSerializer,
        topicName: String,
        messageSize: MessageSize
    ): KafkaBenchmarkResult {
        
        val producerProps = Properties().apply {
            put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, config.bootstrapServers)
            put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer::class.java.name)
            put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ByteArraySerializer::class.java.name)
            put(ProducerConfig.ACKS_CONFIG, "all")
            put(ProducerConfig.LINGER_MS_CONFIG, 0) // 지연 최소화
            put(ProducerConfig.BATCH_SIZE_CONFIG, 16384)
            config.securityConfig?.let { putAll(it) }
        }
        
        val consumerProps = Properties().apply {
            put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, config.bootstrapServers)
            put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer::class.java.name)
            put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer::class.java.name)
            put(ConsumerConfig.GROUP_ID_CONFIG, "benchmark-${UUID.randomUUID()}")
            put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest")
            put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false")
            put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 1000)
            config.securityConfig?.let { putAll(it) }
        }
        
        // 테스트 데이터 생성
        val warmupEvents = (1..warmupMessages).map { TestDataGenerator.generateBySize(messageSize) }
        val testEvents = (1..measureMessages).map { TestDataGenerator.generateBySize(messageSize) }
        
        val produceLatencyHistogram = Histogram(TimeUnit.SECONDS.toNanos(60), 3)
        val consumeLatencyHistogram = Histogram(TimeUnit.SECONDS.toNanos(60), 3)
        var totalSerializedSize = 0L
        
        KafkaProducer<String, ByteArray>(producerProps).use { producer ->
            
            // Warmup
            logger.info { "  Producer 워밍업 중..." }
            for (event in warmupEvents) {
                val bytes = serializer.serialize(event)
                producer.send(ProducerRecord(topicName, event.eventId, bytes)).get()
            }
            producer.flush()
            
            // 측정: Produce
            logger.info { "  Produce 측정 중... ($measureMessages messages)" }
            val produceStartTime = System.currentTimeMillis()
            val sendTimestamps = mutableMapOf<String, Long>()
            
            for (event in testEvents) {
                val iterStart = System.nanoTime()
                val bytes = serializer.serialize(event)
                totalSerializedSize += bytes.size
                
                sendTimestamps[event.eventId] = System.currentTimeMillis()
                producer.send(ProducerRecord(topicName, event.eventId, bytes)) { _, ex ->
                    if (ex != null) {
                        logger.error(ex) { "전송 실패: ${event.eventId}" }
                    }
                }
                produceLatencyHistogram.recordValue(System.nanoTime() - iterStart)
            }
            producer.flush()
            val produceEndTime = System.currentTimeMillis()
            val produceTimeMs = produceEndTime - produceStartTime
            
            // 측정: Consume
            logger.info { "  Consume 측정 중..." }
            KafkaConsumer<String, ByteArray>(consumerProps).use { consumer ->
                consumer.subscribe(listOf(topicName))
                
                var consumedCount = 0
                val consumeStartTime = System.currentTimeMillis()
                val targetCount = warmupMessages + measureMessages
                
                while (consumedCount < targetCount) {
                    val records = consumer.poll(Duration.ofSeconds(10))
                    
                    for (record in records) {
                        if (record.key() in sendTimestamps) {
                            val iterStart = System.nanoTime()
                            serializer.deserialize(record.value())
                            consumeLatencyHistogram.recordValue(System.nanoTime() - iterStart)
                        }
                        consumedCount++
                    }
                }
                
                val consumeEndTime = System.currentTimeMillis()
                val consumeTimeMs = consumeEndTime - consumeStartTime
                
                return KafkaBenchmarkResult(
                    serializerName = serializer.name,
                    messageSize = messageSize,
                    messageCount = measureMessages,
                    avgSerializedSizeBytes = totalSerializedSize.toDouble() / measureMessages,
                    produceTimeMs = produceTimeMs,
                    consumeTimeMs = consumeTimeMs,
                    endToEndTimeMs = consumeEndTime - produceStartTime,
                    produceLatencyHistogram = produceLatencyHistogram,
                    consumeLatencyHistogram = consumeLatencyHistogram,
                    produceThroughput = measureMessages / (produceTimeMs / 1000.0),
                    consumeThroughput = measureMessages / (consumeTimeMs / 1000.0)
                )
            }
        }
    }
    
    private fun printKafkaResult(result: KafkaBenchmarkResult) {
        println("""
            |
            |  📊 ${result.serializerName} Kafka E2E (${result.messageSize})
            |  ─────────────────────────────────────────────
            |  메시지 수: ${result.messageCount}
            |  평균 직렬화 크기: ${String.format("%.0f", result.avgSerializedSizeBytes)} bytes
            |  
            |  📤 Produce
            |     총 시간: ${result.produceTimeMs} ms
            |     처리량: ${String.format("%.0f", result.produceThroughput)} msgs/sec
            |     p50 지연: ${String.format("%.2f", result.produceLatencyHistogram.getValueAtPercentile(50.0) / 1_000_000.0)} ms
            |     p99 지연: ${String.format("%.2f", result.produceLatencyHistogram.getValueAtPercentile(99.0) / 1_000_000.0)} ms
            |  
            |  📥 Consume
            |     총 시간: ${result.consumeTimeMs} ms
            |     처리량: ${String.format("%.0f", result.consumeThroughput)} msgs/sec
            |     p50 지연: ${String.format("%.2f", result.consumeLatencyHistogram.getValueAtPercentile(50.0) / 1_000_000.0)} ms
            |     p99 지연: ${String.format("%.2f", result.consumeLatencyHistogram.getValueAtPercentile(99.0) / 1_000_000.0)} ms
            |  
            |  🔄 End-to-End: ${result.endToEndTimeMs} ms
            |
        """.trimMargin())
    }
}

/**
 * Kafka 벤치마크 결과 리포터
 */
class KafkaBenchmarkReporter {
    
    fun generateReport(results: List<KafkaBenchmarkResult>): String {
        val sb = StringBuilder()
        
        sb.appendLine("=" .repeat(100))
        sb.appendLine("  KAFKA END-TO-END 직렬화 포맷 벤치마크 결과")
        sb.appendLine("=".repeat(100))
        sb.appendLine()
        
        val bySize = results.groupBy { it.messageSize }
        
        for ((size, sizeResults) in bySize) {
            sb.appendLine("━".repeat(100))
            sb.appendLine("  메시지 크기: $size")
            sb.appendLine("━".repeat(100))
            
            sb.appendLine(String.format(
                "%-12s %10s %10s %10s %10s %12s %12s",
                "Format", "Avg Size", "Produce", "Consume", "E2E", "Prod Thr.", "Cons Thr."
            ))
            sb.appendLine("-".repeat(100))
            
            val sortedResults = sizeResults.sortedBy { it.endToEndTimeMs }
            
            for (result in sortedResults) {
                sb.appendLine(String.format(
                    "%-12s %8.0f B %8d ms %8d ms %8d ms %10.0f/s %10.0f/s",
                    result.serializerName,
                    result.avgSerializedSizeBytes,
                    result.produceTimeMs,
                    result.consumeTimeMs,
                    result.endToEndTimeMs,
                    result.produceThroughput,
                    result.consumeThroughput
                ))
            }
            
            sb.appendLine()
        }
        
        return sb.toString()
    }
    
    fun generateCsv(results: List<KafkaBenchmarkResult>): String {
        val sb = StringBuilder()
        sb.appendLine("Format,MessageSize,Count,AvgSizeBytes,ProduceMs,ConsumeMs,E2EMs,ProduceThroughput,ConsumeThroughput,ProduceP50ms,ProduceP99ms,ConsumeP50ms,ConsumeP99ms")
        
        for (result in results) {
            sb.appendLine(listOf(
                result.serializerName,
                result.messageSize,
                result.messageCount,
                String.format("%.2f", result.avgSerializedSizeBytes),
                result.produceTimeMs,
                result.consumeTimeMs,
                result.endToEndTimeMs,
                String.format("%.0f", result.produceThroughput),
                String.format("%.0f", result.consumeThroughput),
                String.format("%.2f", result.produceLatencyHistogram.getValueAtPercentile(50.0) / 1_000_000.0),
                String.format("%.2f", result.produceLatencyHistogram.getValueAtPercentile(99.0) / 1_000_000.0),
                String.format("%.2f", result.consumeLatencyHistogram.getValueAtPercentile(50.0) / 1_000_000.0),
                String.format("%.2f", result.consumeLatencyHistogram.getValueAtPercentile(99.0) / 1_000_000.0)
            ).joinToString(","))
        }
        
        return sb.toString()
    }
}
