package com.example.benchmark.config

import java.io.File
import java.util.*

/**
 * Kafka 클러스터 설정
 */
data class KafkaConfig(
    val bootstrapServers: String,
    val partitions: Int = 3,
    val replicationFactor: Int = 1,
    val securityConfig: Properties? = null
) {
    companion object {
        
        /**
         * 로컬 개발 환경 설정
         */
        fun local(): KafkaConfig = KafkaConfig(
            bootstrapServers = "localhost:9092",
            partitions = 1,
            replicationFactor = 1
        )
        
        /**
         * Strimzi 클러스터 설정 (Plain - 인증 없음)
         */
        fun strimziPlain(
            bootstrapServers: String,
            partitions: Int = 3,
            replicationFactor: Int = 3
        ): KafkaConfig = KafkaConfig(
            bootstrapServers = bootstrapServers,
            partitions = partitions,
            replicationFactor = replicationFactor
        )
        
        /**
         * Strimzi 클러스터 설정 (TLS)
         */
        fun strimziTls(
            bootstrapServers: String,
            truststorePath: String,
            truststorePassword: String,
            partitions: Int = 3,
            replicationFactor: Int = 3
        ): KafkaConfig {
            val securityProps = Properties().apply {
                put("security.protocol", "SSL")
                put("ssl.truststore.location", truststorePath)
                put("ssl.truststore.password", truststorePassword)
                put("ssl.endpoint.identification.algorithm", "")
            }
            
            return KafkaConfig(
                bootstrapServers = bootstrapServers,
                partitions = partitions,
                replicationFactor = replicationFactor,
                securityConfig = securityProps
            )
        }
        
        /**
         * Strimzi 클러스터 설정 (mTLS)
         */
        fun strimziMtls(
            bootstrapServers: String,
            truststorePath: String,
            truststorePassword: String,
            keystorePath: String,
            keystorePassword: String,
            partitions: Int = 3,
            replicationFactor: Int = 3
        ): KafkaConfig {
            val securityProps = Properties().apply {
                put("security.protocol", "SSL")
                put("ssl.truststore.location", truststorePath)
                put("ssl.truststore.password", truststorePassword)
                put("ssl.keystore.location", keystorePath)
                put("ssl.keystore.password", keystorePassword)
                put("ssl.endpoint.identification.algorithm", "")
            }
            
            return KafkaConfig(
                bootstrapServers = bootstrapServers,
                partitions = partitions,
                replicationFactor = replicationFactor,
                securityConfig = securityProps
            )
        }
        
        /**
         * Strimzi 클러스터 설정 (SASL/SCRAM)
         */
        fun strimziScram(
            bootstrapServers: String,
            username: String,
            password: String,
            truststorePath: String? = null,
            truststorePassword: String? = null,
            partitions: Int = 3,
            replicationFactor: Int = 3
        ): KafkaConfig {
            val securityProps = Properties().apply {
                if (truststorePath != null) {
                    put("security.protocol", "SASL_SSL")
                    put("ssl.truststore.location", truststorePath)
                    put("ssl.truststore.password", truststorePassword)
                    put("ssl.endpoint.identification.algorithm", "")
                } else {
                    put("security.protocol", "SASL_PLAINTEXT")
                }
                put("sasl.mechanism", "SCRAM-SHA-512")
                put("sasl.jaas.config", 
                    "org.apache.kafka.common.security.scram.ScramLoginModule required " +
                    "username=\"$username\" password=\"$password\";")
            }
            
            return KafkaConfig(
                bootstrapServers = bootstrapServers,
                partitions = partitions,
                replicationFactor = replicationFactor,
                securityConfig = securityProps
            )
        }
        
        /**
         * Strimzi 클러스터 설정 (OAuth/Keycloak)
         * 
         * 이 설정을 사용하려면 추가 의존성 필요:
         * implementation("io.strimzi:kafka-oauth-client:0.14.0")
         */
        fun strimziOAuth(
            bootstrapServers: String,
            tokenEndpoint: String,
            clientId: String,
            clientSecret: String,
            truststorePath: String? = null,
            truststorePassword: String? = null,
            partitions: Int = 3,
            replicationFactor: Int = 3
        ): KafkaConfig {
            val securityProps = Properties().apply {
                if (truststorePath != null) {
                    put("security.protocol", "SASL_SSL")
                    put("ssl.truststore.location", truststorePath)
                    put("ssl.truststore.password", truststorePassword)
                    put("ssl.endpoint.identification.algorithm", "")
                } else {
                    put("security.protocol", "SASL_PLAINTEXT")
                }
                put("sasl.mechanism", "OAUTHBEARER")
                put("sasl.jaas.config", 
                    "org.apache.kafka.common.security.oauthbearer.OAuthBearerLoginModule required " +
                    "oauth.token.endpoint.uri=\"$tokenEndpoint\" " +
                    "oauth.client.id=\"$clientId\" " +
                    "oauth.client.secret=\"$clientSecret\";")
                put("sasl.login.callback.handler.class", 
                    "io.strimzi.kafka.oauth.client.JaasClientOauthLoginCallbackHandler")
            }
            
            return KafkaConfig(
                bootstrapServers = bootstrapServers,
                partitions = partitions,
                replicationFactor = replicationFactor,
                securityConfig = securityProps
            )
        }
        
        /**
         * 환경 변수에서 설정 로드
         */
        fun fromEnvironment(): KafkaConfig {
            val bootstrapServers = System.getenv("KAFKA_BOOTSTRAP_SERVERS") 
                ?: "localhost:9092"
            val securityProtocol = System.getenv("KAFKA_SECURITY_PROTOCOL")
            
            val securityProps = when (securityProtocol) {
                "SSL" -> Properties().apply {
                    put("security.protocol", "SSL")
                    put("ssl.truststore.location", System.getenv("KAFKA_SSL_TRUSTSTORE_LOCATION"))
                    put("ssl.truststore.password", System.getenv("KAFKA_SSL_TRUSTSTORE_PASSWORD"))
                    System.getenv("KAFKA_SSL_KEYSTORE_LOCATION")?.let {
                        put("ssl.keystore.location", it)
                        put("ssl.keystore.password", System.getenv("KAFKA_SSL_KEYSTORE_PASSWORD"))
                    }
                    put("ssl.endpoint.identification.algorithm", "")
                }
                "SASL_SSL", "SASL_PLAINTEXT" -> Properties().apply {
                    put("security.protocol", securityProtocol)
                    put("sasl.mechanism", System.getenv("KAFKA_SASL_MECHANISM") ?: "SCRAM-SHA-512")
                    put("sasl.jaas.config", System.getenv("KAFKA_SASL_JAAS_CONFIG"))
                    if (securityProtocol == "SASL_SSL") {
                        put("ssl.truststore.location", System.getenv("KAFKA_SSL_TRUSTSTORE_LOCATION"))
                        put("ssl.truststore.password", System.getenv("KAFKA_SSL_TRUSTSTORE_PASSWORD"))
                        put("ssl.endpoint.identification.algorithm", "")
                    }
                }
                else -> null
            }
            
            return KafkaConfig(
                bootstrapServers = bootstrapServers,
                partitions = System.getenv("KAFKA_PARTITIONS")?.toIntOrNull() ?: 3,
                replicationFactor = System.getenv("KAFKA_REPLICATION_FACTOR")?.toIntOrNull() ?: 1,
                securityConfig = securityProps
            )
        }
        
        /**
         * 프로퍼티 파일에서 설정 로드
         */
        fun fromPropertiesFile(filePath: String): KafkaConfig {
            val props = Properties()
            File(filePath).inputStream().use { props.load(it) }
            
            val bootstrapServers = props.getProperty("bootstrap.servers", "localhost:9092")
            val securityProtocol = props.getProperty("security.protocol")
            
            val securityProps = if (securityProtocol != null) {
                Properties().apply {
                    props.stringPropertyNames()
                        .filter { it.startsWith("security.") || it.startsWith("ssl.") || it.startsWith("sasl.") }
                        .forEach { put(it, props.getProperty(it)) }
                }
            } else null
            
            return KafkaConfig(
                bootstrapServers = bootstrapServers,
                partitions = props.getProperty("num.partitions", "3").toInt(),
                replicationFactor = props.getProperty("replication.factor", "1").toInt(),
                securityConfig = securityProps
            )
        }
    }
}

/**
 * 벤치마크 설정
 */
data class BenchmarkConfig(
    val warmupIterations: Int = 1000,
    val measureIterations: Int = 100_000,
    val kafkaWarmupMessages: Int = 100,
    val kafkaMeasureMessages: Int = 10_000,
    val outputDir: String = "./benchmark-results"
) {
    companion object {
        fun default() = BenchmarkConfig()
        
        fun quick() = BenchmarkConfig(
            warmupIterations = 100,
            measureIterations = 10_000,
            kafkaWarmupMessages = 10,
            kafkaMeasureMessages = 1_000
        )
        
        fun full() = BenchmarkConfig(
            warmupIterations = 5000,
            measureIterations = 500_000,
            kafkaWarmupMessages = 500,
            kafkaMeasureMessages = 50_000
        )
    }
}
