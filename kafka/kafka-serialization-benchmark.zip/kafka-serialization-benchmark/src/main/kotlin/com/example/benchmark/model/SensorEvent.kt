package com.example.benchmark.model

import com.fasterxml.jackson.annotation.JsonProperty
import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * 공통 데이터 모델 - 모든 직렬화 포맷에서 동일한 구조 사용
 */
@Serializable
data class SensorEvent(
    @JsonProperty("event_id")
    val eventId: String = UUID.randomUUID().toString(),
    
    val timestamp: Long = System.currentTimeMillis(),
    
    @JsonProperty("device_id")
    val deviceId: String,
    
    @JsonProperty("device_type")
    val deviceType: String,
    
    val location: Location,
    
    val readings: List<Reading>,
    
    val metadata: Map<String, String> = emptyMap(),
    
    val status: EventStatus = EventStatus.STATUS_NORMAL
)

@Serializable
data class Location(
    val latitude: Double,
    val longitude: Double,
    val zone: String,
    val building: String,
    val floor: Int
)

@Serializable
data class Reading(
    @JsonProperty("sensor_type")
    val sensorType: String,
    
    val value: Double,
    val unit: String,
    val timestamp: Long = System.currentTimeMillis(),
    val quality: ReadingQuality = ReadingQuality.GOOD
)

@Serializable
enum class ReadingQuality {
    UNKNOWN, GOOD, SUSPECT, BAD
}

@Serializable
enum class EventStatus {
    STATUS_UNKNOWN, STATUS_NORMAL, STATUS_WARNING, STATUS_ALERT, STATUS_CRITICAL
}

/**
 * 테스트 데이터 생성기
 */
object TestDataGenerator {
    
    private val deviceTypes = listOf("temperature", "humidity", "pressure", "vibration", "current")
    private val zones = listOf("A", "B", "C", "D", "E")
    private val buildings = listOf("Main", "Annex", "Warehouse", "Lab", "Office")
    private val sensorTypes = listOf("temp", "humid", "press", "vib", "amp", "volt", "flow", "level")
    private val units = listOf("°C", "%RH", "kPa", "mm/s", "A", "V", "L/min", "m")
    
    /**
     * 단일 이벤트 생성
     * @param readingCount 리딩 개수 (메시지 크기 조절용)
     */
    fun generateEvent(readingCount: Int = 5): SensorEvent {
        return SensorEvent(
            eventId = UUID.randomUUID().toString(),
            timestamp = System.currentTimeMillis(),
            deviceId = "DEV-${(1000..9999).random()}",
            deviceType = deviceTypes.random(),
            location = Location(
                latitude = 37.0 + Math.random() * 0.1,
                longitude = 127.0 + Math.random() * 0.1,
                zone = zones.random(),
                building = buildings.random(),
                floor = (1..10).random()
            ),
            readings = (1..readingCount).map { generateReading() },
            metadata = mapOf(
                "version" to "1.0",
                "source" to "benchmark-test",
                "correlation_id" to UUID.randomUUID().toString(),
                "batch_seq" to "${(1..1000).random()}"
            ),
            status = EventStatus.entries.random()
        )
    }
    
    private fun generateReading(): Reading {
        val idx = (sensorTypes.indices).random()
        return Reading(
            sensorType = sensorTypes[idx],
            value = Math.random() * 100,
            unit = units[idx],
            timestamp = System.currentTimeMillis(),
            quality = ReadingQuality.entries.random()
        )
    }
    
    /**
     * 대량 이벤트 생성
     */
    fun generateEvents(count: Int, readingCount: Int = 5): List<SensorEvent> {
        return (1..count).map { generateEvent(readingCount) }
    }
    
    /**
     * 메시지 크기별 테스트 데이터 생성
     * - Small: ~200 bytes (2 readings)
     * - Medium: ~1KB (10 readings)
     * - Large: ~5KB (50 readings)
     */
    fun generateBySize(size: MessageSize): SensorEvent {
        return when (size) {
            MessageSize.SMALL -> generateEvent(2)
            MessageSize.MEDIUM -> generateEvent(10)
            MessageSize.LARGE -> generateEvent(50)
        }
    }
}

enum class MessageSize {
    SMALL, MEDIUM, LARGE
}
