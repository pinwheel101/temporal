#!/bin/bash
#
# Kafka 직렬화 포맷 벤치마크 실행 스크립트
#

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_header() {
    echo -e "${GREEN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║     Kafka 직렬화 포맷 벤치마크 도구                           ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

check_gradle() {
    if [ ! -f "gradlew" ]; then
        echo -e "${YELLOW}Gradle Wrapper가 없습니다. 생성 중...${NC}"
        gradle wrapper --gradle-version 8.5
    fi
}

build() {
    echo -e "${GREEN}빌드 중...${NC}"
    ./gradlew build -x test
    echo -e "${GREEN}빌드 완료!${NC}"
}

run_pure() {
    echo -e "${GREEN}순수 직렬화 벤치마크 실행 중...${NC}"
    ./gradlew run --args="pure $*"
}

run_kafka() {
    echo -e "${GREEN}Kafka E2E 벤치마크 실행 중...${NC}"
    ./gradlew run --args="kafka $*"
}

run_size_check() {
    echo -e "${GREEN}메시지 크기 확인 중...${NC}"
    ./gradlew run --args="size-check"
}

show_help() {
    print_header
    echo "사용법: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  build        프로젝트 빌드"
    echo "  pure         순수 직렬화 벤치마크 (Kafka 없이)"
    echo "  kafka        Kafka E2E 벤치마크"
    echo "  size-check   메시지 크기 확인"
    echo "  help         이 도움말 표시"
    echo ""
    echo "Examples:"
    echo "  $0 build"
    echo "  $0 pure -n 50000"
    echo "  $0 kafka -b my-cluster-kafka-bootstrap:9092 -n 10000"
    echo "  $0 kafka -c config/client.properties"
    echo ""
    echo "상세 옵션은 './run.sh <command> --help'를 참조하세요."
}

# Main
case "${1:-help}" in
    build)
        shift
        check_gradle
        build
        ;;
    pure)
        shift
        check_gradle
        run_pure "$@"
        ;;
    kafka)
        shift
        check_gradle
        run_kafka "$@"
        ;;
    size-check)
        shift
        check_gradle
        run_size_check
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo -e "${RED}알 수 없는 명령어: $1${NC}"
        show_help
        exit 1
        ;;
esac
