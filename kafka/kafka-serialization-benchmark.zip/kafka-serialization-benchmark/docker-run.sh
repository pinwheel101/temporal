#!/bin/bash
#
# Docker 기반 Kafka 직렬화 벤치마크 실행 스크립트
#
# 사용법:
#   ./docker-run.sh start       # Kafka 클러스터 시작
#   ./docker-run.sh stop        # 클러스터 중지
#   ./docker-run.sh pure        # 순수 직렬화 벤치마크
#   ./docker-run.sh kafka       # Kafka E2E 벤치마크
#   ./docker-run.sh quick       # 빠른 테스트
#   ./docker-run.sh full        # 대용량 테스트
#   ./docker-run.sh size        # 메시지 크기 확인
#   ./docker-run.sh ui          # Kafka UI 포함 시작
#   ./docker-run.sh logs        # Kafka 로그 확인
#   ./docker-run.sh shell       # 벤치마크 컨테이너 쉘 접속

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 결과 디렉토리 생성
mkdir -p results

print_header() {
    echo -e "${BLUE}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║   Docker 기반 Kafka 직렬화 포맷 벤치마크                      ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 이미지 빌드 (필요시)
build_image() {
    if [[ "$(docker images -q kafka-benchmark 2> /dev/null)" == "" ]] || [[ "$1" == "--force" ]]; then
        print_status "벤치마크 이미지 빌드 중..."
        docker-compose build benchmark-pure
        print_status "이미지 빌드 완료!"
    fi
}

# Kafka 클러스터 시작
start_kafka() {
    print_status "Kafka 클러스터 시작 중..."
    docker-compose up -d kafka
    
    print_status "Kafka 준비 대기 중..."
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if docker-compose exec -T kafka kafka-topics.sh --bootstrap-server localhost:9092 --list &>/dev/null; then
            print_status "Kafka 준비 완료!"
            echo ""
            echo -e "  📡 Kafka Bootstrap Server:"
            echo -e "     - 컨테이너 내부: ${GREEN}kafka:9092${NC}"
            echo -e "     - 호스트에서:    ${GREEN}localhost:9094${NC}"
            echo ""
            return 0
        fi
        echo -n "."
        sleep 2
        attempt=$((attempt + 1))
    done
    
    print_error "Kafka 시작 실패!"
    return 1
}

# Kafka 클러스터 중지
stop_kafka() {
    print_status "Kafka 클러스터 중지 중..."
    docker-compose down -v
    print_status "클러스터 중지 완료!"
}

# Kafka UI 포함 시작
start_with_ui() {
    print_status "Kafka 클러스터 + UI 시작 중..."
    docker-compose --profile ui up -d
    
    print_status "Kafka 준비 대기 중..."
    sleep 10
    
    echo ""
    echo -e "  📡 Kafka Bootstrap Server: ${GREEN}localhost:9094${NC}"
    echo -e "  🖥️  Kafka UI: ${GREEN}http://localhost:8080${NC}"
    echo ""
}

# 순수 직렬화 벤치마크
run_pure() {
    build_image
    print_status "순수 직렬화 벤치마크 실행 중..."
    
    local args="${@:-"-n 100000"}"
    docker-compose run --rm benchmark-pure pure $args -o /results/pure-results.csv
    
    print_status "결과 파일: results/pure-results.csv"
}

# Kafka E2E 벤치마크
run_kafka() {
    build_image
    
    # Kafka가 실행 중인지 확인
    if ! docker-compose ps kafka 2>/dev/null | grep -q "Up"; then
        print_warning "Kafka가 실행 중이 아닙니다. 시작합니다..."
        start_kafka
    fi
    
    print_status "Kafka E2E 벤치마크 실행 중..."
    
    local args="${@:-"-n 10000"}"
    docker-compose run --rm benchmark-kafka kafka -b kafka:9092 $args -o /results/kafka-results.csv
    
    print_status "결과 파일: results/kafka-results.csv"
}

# 빠른 테스트
run_quick() {
    build_image
    
    if ! docker-compose ps kafka 2>/dev/null | grep -q "Up"; then
        print_warning "Kafka가 실행 중이 아닙니다. 시작합니다..."
        start_kafka
    fi
    
    print_status "빠른 벤치마크 실행 중..."
    docker-compose --profile quick up benchmark-quick
    
    print_status "결과 파일: results/quick-results.csv"
}

# 대용량 테스트
run_full() {
    build_image
    
    if ! docker-compose ps kafka 2>/dev/null | grep -q "Up"; then
        print_warning "Kafka가 실행 중이 아닙니다. 시작합니다..."
        start_kafka
    fi
    
    print_status "대용량 벤치마크 실행 중 (시간이 걸릴 수 있습니다)..."
    docker-compose --profile full up benchmark-full
    
    print_status "결과 파일: results/full-results.csv"
}

# 메시지 크기 확인
run_size_check() {
    build_image
    print_status "메시지 크기 확인 중..."
    docker-compose --profile size up benchmark-size
}

# Kafka 로그 확인
show_logs() {
    docker-compose logs -f kafka
}

# 벤치마크 쉘 접속
run_shell() {
    build_image
    print_status "벤치마크 컨테이너 쉘 접속..."
    docker-compose run --rm --entrypoint /bin/bash benchmark-pure
}

# 상태 확인
show_status() {
    echo ""
    print_status "컨테이너 상태:"
    docker-compose ps
    echo ""
    
    if docker-compose ps kafka 2>/dev/null | grep -q "Up"; then
        print_status "Kafka 토픽 목록:"
        docker-compose exec -T kafka kafka-topics.sh --bootstrap-server localhost:9092 --list 2>/dev/null || echo "  (조회 실패)"
    fi
}

# 결과 보기
show_results() {
    echo ""
    print_status "벤치마크 결과 파일:"
    ls -la results/*.csv 2>/dev/null || echo "  결과 파일이 없습니다."
    echo ""
    
    if [ -f "results/pure-results.csv" ]; then
        echo -e "${GREEN}=== 순수 직렬화 결과 (pure-results.csv) ===${NC}"
        head -20 results/pure-results.csv
        echo ""
    fi
    
    if [ -f "results/kafka-results.csv" ]; then
        echo -e "${GREEN}=== Kafka E2E 결과 (kafka-results.csv) ===${NC}"
        head -20 results/kafka-results.csv
        echo ""
    fi
}

# 도움말
show_help() {
    print_header
    echo "사용법: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  start       Kafka 클러스터 시작"
    echo "  stop        Kafka 클러스터 중지 (데이터 삭제)"
    echo "  status      컨테이너 상태 확인"
    echo "  ui          Kafka UI 포함하여 시작 (http://localhost:8080)"
    echo "  logs        Kafka 로그 확인"
    echo ""
    echo "  pure        순수 직렬화 벤치마크 (Kafka 없이)"
    echo "  kafka       Kafka E2E 벤치마크"
    echo "  quick       빠른 테스트 (적은 메시지)"
    echo "  full        대용량 테스트"
    echo "  size        메시지 크기 확인"
    echo ""
    echo "  results     결과 파일 확인"
    echo "  shell       벤치마크 컨테이너 쉘 접속"
    echo "  build       이미지 강제 재빌드"
    echo "  help        이 도움말"
    echo ""
    echo "Examples:"
    echo "  $0 start                    # Kafka 시작"
    echo "  $0 pure -n 50000            # 5만 건 순수 벤치마크"
    echo "  $0 kafka -n 5000 -s MEDIUM  # 5천 건 MEDIUM 크기로 E2E 테스트"
    echo "  $0 ui                       # Kafka + UI 시작"
    echo "  $0 results                  # 결과 확인"
    echo ""
    echo "호스트에서 직접 Kafka 연결:"
    echo "  kafka-console-producer.sh --bootstrap-server localhost:9094 --topic test"
    echo ""
}

# Main
case "${1:-help}" in
    start)
        print_header
        start_kafka
        ;;
    stop)
        print_header
        stop_kafka
        ;;
    status)
        print_header
        show_status
        ;;
    ui)
        print_header
        start_with_ui
        ;;
    logs)
        show_logs
        ;;
    pure)
        shift
        print_header
        run_pure "$@"
        ;;
    kafka)
        shift
        print_header
        run_kafka "$@"
        ;;
    quick)
        print_header
        run_quick
        ;;
    full)
        print_header
        run_full
        ;;
    size|size-check)
        print_header
        run_size_check
        ;;
    results)
        print_header
        show_results
        ;;
    shell)
        print_header
        run_shell
        ;;
    build)
        print_header
        build_image --force
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        print_error "알 수 없는 명령어: $1"
        show_help
        exit 1
        ;;
esac
