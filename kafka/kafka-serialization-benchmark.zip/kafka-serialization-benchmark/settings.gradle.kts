rootProject.name = "kafka-serialization-benchmark"
