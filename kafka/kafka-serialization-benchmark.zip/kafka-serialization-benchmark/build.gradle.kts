import com.google.protobuf.gradle.*

plugins {
    kotlin("jvm") version "1.9.22"
    kotlin("plugin.serialization") version "1.9.22"
    id("com.google.protobuf") version "0.9.4"
    id("com.github.johnrengelman.shadow") version "8.1.1"
    application
}

group = "com.example"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://packages.confluent.io/maven/")
}

val kafkaVersion = "3.7.0"
val confluentVersion = "7.6.0"
val avroVersion = "1.11.3"
val protobufVersion = "3.25.3"

dependencies {
    // Kotlin
    implementation(kotlin("stdlib"))
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.8.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
    
    // Kafka
    implementation("org.apache.kafka:kafka-clients:$kafkaVersion")
    
    // Avro
    implementation("org.apache.avro:avro:$avroVersion")
    implementation("io.confluent:kafka-avro-serializer:$confluentVersion")
    
    // Protobuf
    implementation("com.google.protobuf:protobuf-java:$protobufVersion")
    implementation("com.google.protobuf:protobuf-java-util:$protobufVersion")
    implementation("io.confluent:kafka-protobuf-serializer:$confluentVersion")
    
    // JSON Schema
    implementation("io.confluent:kafka-json-schema-serializer:$confluentVersion")
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.16.1")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.16.1")
    
    // MessagePack
    implementation("org.msgpack:msgpack-core:0.9.8")
    implementation("org.msgpack:jackson-dataformat-msgpack:0.9.8")
    
    // Logging
    implementation("ch.qos.logback:logback-classic:1.4.14")
    implementation("io.github.microutils:kotlin-logging-jvm:3.0.5")
    
    // CLI
    implementation("com.github.ajalt.clikt:clikt:4.2.2")
    
    // HdrHistogram for latency measurement
    implementation("org.hdrhistogram:HdrHistogram:2.1.12")
    
    // Testing
    testImplementation(kotlin("test"))
}

protobuf {
    protoc {
        artifact = "com.google.protobuf:protoc:$protobufVersion"
    }
}

sourceSets {
    main {
        proto {
            srcDir("src/main/proto")
        }
    }
}

tasks.test {
    useJUnitPlatform()
}

kotlin {
    jvmToolchain(17)
}

application {
    mainClass.set("com.example.benchmark.MainKt")
}

tasks.shadowJar {
    archiveBaseName.set("kafka-benchmark")
    archiveClassifier.set("all")
    archiveVersion.set("")
    mergeServiceFiles()
    manifest {
        attributes["Main-Class"] = "com.example.benchmark.MainKt"
    }
}

tasks.build {
    dependsOn(tasks.shadowJar)
}
