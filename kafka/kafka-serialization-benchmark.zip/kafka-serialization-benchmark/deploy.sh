#!/bin/bash
#
# Kafka 직렬화 벤치마크 빌드 및 배포 스크립트
# Strimzi 환경용
#

set -e

# 설정
IMAGE_NAME="${IMAGE_NAME:-kafka-serialization-benchmark}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
KAFKA_NAMESPACE="${KAFKA_NAMESPACE:-kafka}"
KAFKA_CLUSTER="${KAFKA_CLUSTER:-my-cluster}"

# 색상 출력
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 사용법 출력
usage() {
    echo "사용법: $0 <command>"
    echo ""
    echo "Commands:"
    echo "  build       - Docker 이미지 빌드"
    echo "  push        - Docker 이미지 푸시 (레지스트리 필요)"
    echo "  deploy      - Kubernetes에 벤치마크 Job 배포"
    echo "  run-local   - 로컬 벤치마크만 실행"
    echo "  run-kafka   - Kafka 통합 벤치마크 실행"
    echo "  run-all     - 전체 벤치마크 실행"
    echo "  logs        - 벤치마크 로그 확인"
    echo "  clean       - 벤치마크 Job 정리"
    echo "  status      - 현재 상태 확인"
    echo ""
    echo "환경변수:"
    echo "  IMAGE_NAME      - 이미지 이름 (기본: kafka-serialization-benchmark)"
    echo "  IMAGE_TAG       - 이미지 태그 (기본: latest)"
    echo "  KAFKA_NAMESPACE - Kafka 네임스페이스 (기본: kafka)"
    echo "  KAFKA_CLUSTER   - Strimzi 클러스터 이름 (기본: my-cluster)"
}

# Gradle 빌드
build_jar() {
    log_info "Gradle 빌드 시작..."
    ./gradlew clean jar
    log_info "JAR 빌드 완료"
}

# Docker 이미지 빌드
build_image() {
    log_info "Docker 이미지 빌드: ${IMAGE_NAME}:${IMAGE_TAG}"
    docker build -t ${IMAGE_NAME}:${IMAGE_TAG} .
    log_info "Docker 이미지 빌드 완료"
}

# Docker 이미지 푸시
push_image() {
    log_info "Docker 이미지 푸시: ${IMAGE_NAME}:${IMAGE_TAG}"
    docker push ${IMAGE_NAME}:${IMAGE_TAG}
    log_info "Docker 이미지 푸시 완료"
}

# Kubernetes 리소스 배포
deploy() {
    local job_type=$1
    
    log_info "Kubernetes 배포 시작..."
    
    # Bootstrap 서버 업데이트
    local bootstrap_server="${KAFKA_CLUSTER}-kafka-bootstrap:9092"
    
    case $job_type in
        local)
            log_info "로컬 벤치마크 Job 배포"
            kubectl apply -f k8s/benchmark-job-local.yaml -n ${KAFKA_NAMESPACE}
            ;;
        kafka)
            log_info "Kafka 통합 벤치마크 Job 배포"
            sed "s/my-cluster-kafka-bootstrap:9092/${bootstrap_server}/g" \
                k8s/benchmark-job-kafka.yaml | kubectl apply -f - -n ${KAFKA_NAMESPACE}
            ;;
        all)
            log_info "전체 벤치마크 Job 배포"
            sed "s/my-cluster-kafka-bootstrap:9092/${bootstrap_server}/g" \
                k8s/benchmark-job-kafka.yaml | kubectl apply -f - -n ${KAFKA_NAMESPACE}
            ;;
        *)
            log_error "알 수 없는 Job 타입: $job_type"
            exit 1
            ;;
    esac
    
    log_info "배포 완료"
}

# 로그 확인
show_logs() {
    local job_name=$(kubectl get jobs -n ${KAFKA_NAMESPACE} -l app=kafka-benchmark \
        --sort-by='.metadata.creationTimestamp' -o jsonpath='{.items[-1].metadata.name}' 2>/dev/null)
    
    if [ -z "$job_name" ]; then
        log_error "실행 중인 벤치마크 Job이 없습니다."
        exit 1
    fi
    
    log_info "Job 로그: $job_name"
    kubectl logs -f job/${job_name} -n ${KAFKA_NAMESPACE}
}

# 정리
clean() {
    log_info "벤치마크 Job 정리..."
    kubectl delete jobs -l app=kafka-benchmark -n ${KAFKA_NAMESPACE} --ignore-not-found
    log_info "정리 완료"
}

# 상태 확인
status() {
    log_info "현재 벤치마크 Job 상태:"
    kubectl get jobs -l app=kafka-benchmark -n ${KAFKA_NAMESPACE} -o wide
    
    echo ""
    log_info "Pod 상태:"
    kubectl get pods -l app=kafka-benchmark -n ${KAFKA_NAMESPACE} -o wide
}

# 메인
case "$1" in
    build)
        build_image
        ;;
    push)
        push_image
        ;;
    deploy)
        deploy ${2:-local}
        ;;
    run-local)
        deploy local
        sleep 2
        show_logs
        ;;
    run-kafka)
        deploy kafka
        sleep 2
        show_logs
        ;;
    run-all)
        deploy all
        sleep 2
        show_logs
        ;;
    logs)
        show_logs
        ;;
    clean)
        clean
        ;;
    status)
        status
        ;;
    *)
        usage
        exit 1
        ;;
esac
