# Kafka 직렬화 포맷 벤치마크

Strimzi Kubernetes 환경에서 Kafka 메시지 직렬화 포맷의 성능을 비교 테스트하는 도구입니다.

## 지원 직렬화 포맷

| 포맷 | 설명 |
|------|------|
| **JSON** | Jackson 기반 텍스트 직렬화 |
| **Protobuf** | Google Protocol Buffers 바이너리 직렬화 |
| **Avro** | Apache Avro 바이너리 직렬화 (Generic Record) |
| **MessagePack** | 바이너리 JSON 호환 포맷 |

## 빠른 시작

### 1. 빌드

```bash
# Gradle Wrapper 생성 (최초 1회)
gradle wrapper --gradle-version 8.5

# 빌드
./gradlew build
```

### 2. 순수 직렬화 벤치마크 (Kafka 없이)

Kafka 클러스터 없이 순수 직렬화/역직렬화 성능만 측정합니다.

```bash
# 기본 실행 (100,000 iterations)
./gradlew run --args="pure"

# 빠른 테스트 (10,000 iterations)
./gradlew run --args="pure -n 10000"

# 특정 메시지 크기만 테스트
./gradlew run --args="pure -s SMALL -s MEDIUM"

# CSV 결과 출력
./gradlew run --args="pure -o results.csv"
```

### 3. 메시지 크기 확인

각 포맷별 직렬화된 메시지 크기를 확인합니다.

```bash
./gradlew run --args="size-check"
```

### 4. Kafka End-to-End 벤치마크

실제 Kafka 클러스터에서 Producer → Broker → Consumer 전체 경로를 테스트합니다.

```bash
# 로컬 Kafka
./gradlew run --args="kafka -b localhost:9092"

# Strimzi 클러스터 (Plain)
./gradlew run --args="kafka -b my-cluster-kafka-bootstrap:9092 -p 3 -r 3"

# Strimzi 클러스터 (TLS)
./gradlew run --args="kafka -b my-cluster-kafka-bootstrap:9093 \
    --truststore /path/to/truststore.jks \
    --truststore-password changeit"

# Strimzi 클러스터 (SCRAM 인증)
./gradlew run --args="kafka -b my-cluster-kafka-bootstrap:9094 \
    -u my-user --password my-password \
    --truststore /path/to/truststore.jks \
    --truststore-password changeit"

# 설정 파일 사용
./gradlew run --args="kafka -c config/client.properties"
```

## CLI 옵션

### pure 명령어

```
Usage: pure [OPTIONS]

순수 직렬화/역직렬화 성능 벤치마크 (Kafka 없이)

Options:
  -w, --warmup INT      워밍업 반복 횟수 (기본: 1000)
  -n, --iterations INT  측정 반복 횟수 (기본: 100000)
  -s, --size VALUE      테스트할 메시지 크기 (SMALL/MEDIUM/LARGE, 여러 번 지정 가능)
  -o, --output-csv PATH CSV 결과 출력 파일
```

### kafka 명령어

```
Usage: kafka [OPTIONS]

Kafka 클러스터 End-to-End 벤치마크

Options:
  -b, --bootstrap-servers TEXT  Kafka bootstrap servers (기본: localhost:9092)
  -p, --partitions INT          테스트 토픽 파티션 수 (기본: 3)
  -r, --replication-factor INT  복제 팩터 (기본: 1)
  -w, --warmup INT              워밍업 메시지 수 (기본: 100)
  -n, --messages INT            측정 메시지 수 (기본: 10000)
  -s, --size VALUE              테스트할 메시지 크기
  -c, --config PATH             Kafka 설정 파일 경로
  -o, --output-csv PATH         CSV 결과 출력 파일
  
  --truststore PATH             SSL truststore 경로
  --truststore-password TEXT    SSL truststore 비밀번호
  -u, --username TEXT           SASL 사용자명
  --password TEXT               SASL 비밀번호
```

## Strimzi 클러스터 연결 설정

### 1. Truststore 추출 (TLS 사용 시)

```bash
# Strimzi 클러스터 CA 인증서 추출
kubectl get secret my-cluster-cluster-ca-cert -n kafka \
    -o jsonpath='{.data.ca\.crt}' | base64 -d > ca.crt

# Truststore 생성
keytool -import -trustcacerts -alias ca \
    -file ca.crt -keystore truststore.jks \
    -storepass changeit -noprompt
```

### 2. SCRAM 사용자 비밀번호 확인

```bash
kubectl get secret my-user -n kafka \
    -o jsonpath='{.data.password}' | base64 -d
```

### 3. 클러스터 외부 접근 (NodePort/LoadBalancer)

```yaml
# Strimzi Kafka CR 예시
apiVersion: kafka.strimzi.io/v1beta2
kind: Kafka
metadata:
  name: my-cluster
spec:
  kafka:
    listeners:
      - name: external
        port: 9094
        type: nodeport
        tls: true
        authentication:
          type: scram-sha-512
```

## 메시지 크기 설명

| 크기 | Reading 수 | 예상 JSON 크기 | 설명 |
|------|-----------|---------------|------|
| SMALL | 2 | ~500 bytes | 간단한 센서 이벤트 |
| MEDIUM | 10 | ~2 KB | 일반적인 운영 데이터 |
| LARGE | 50 | ~10 KB | 배치 또는 집계 데이터 |

## 예상 결과

일반적인 환경에서 예상되는 상대적 성능:

| 포맷 | 직렬화 속도 | 메시지 크기 |
|------|-----------|-----------|
| Protobuf | 🏆 가장 빠름 | 🏆 가장 작음 |
| MessagePack | 빠름 | 작음 |
| Avro | 중간 | 작음 |
| JSON | 느림 | 가장 큼 |

## 프로젝트 구조

```
kafka-serialization-benchmark/
├── build.gradle.kts              # Gradle 빌드 설정
├── settings.gradle.kts
├── config/
│   └── client.properties.example # Strimzi 연결 설정 예시
└── src/main/
    ├── kotlin/com/example/benchmark/
    │   ├── Main.kt               # CLI 진입점
    │   ├── model/
    │   │   └── SensorEvent.kt    # 데이터 모델
    │   ├── serializer/
    │   │   └── Serializers.kt    # 직렬화 구현
    │   ├── benchmark/
    │   │   ├── PureBenchmark.kt  # 순수 벤치마크
    │   │   └── KafkaBenchmark.kt # Kafka E2E 벤치마크
    │   └── config/
    │       └── KafkaConfig.kt    # 설정 클래스
    ├── proto/
    │   └── sensor_event.proto    # Protobuf 스키마
    ├── avro/
    │   └── sensor_event.avsc     # Avro 스키마
    └── resources/
        └── logback.xml           # 로깅 설정
```

## 커스터마이징

### 데이터 모델 변경

1. `src/main/proto/sensor_event.proto` 수정 (Protobuf)
2. `src/main/avro/sensor_event.avsc` 수정 (Avro)
3. `src/main/kotlin/.../model/SensorEvent.kt` 수정 (Kotlin 데이터 클래스)
4. `src/main/kotlin/.../serializer/Serializers.kt`의 변환 로직 수정

### 새 직렬화 포맷 추가

`BenchmarkSerializer` 인터페이스를 구현하고 `SerializerFactory`에 등록:

```kotlin
class MyCustomSerializer : BenchmarkSerializer {
    override val name = "MyFormat"
    
    override fun serialize(event: SensorEvent): ByteArray {
        // 구현
    }
    
    override fun deserialize(bytes: ByteArray): SensorEvent {
        // 구현
    }
}
```

## 트러블슈팅

### Protobuf 컴파일 오류

```bash
# protoc가 설치되어 있는지 확인
protoc --version

# Gradle 캐시 정리 후 재빌드
./gradlew clean build
```

### Kafka 연결 실패

```bash
# 브로커 연결 테스트
kafka-broker-api-versions.sh --bootstrap-server <bootstrap-servers>

# DNS 확인 (Kubernetes 내부)
kubectl run -it --rm debug --image=busybox -- nslookup my-cluster-kafka-bootstrap
```

### 메모리 부족

```bash
# JVM 힙 크기 증가
export JAVA_OPTS="-Xmx4g"
./gradlew run --args="pure -n 500000"
```

## 라이선스

MIT License
